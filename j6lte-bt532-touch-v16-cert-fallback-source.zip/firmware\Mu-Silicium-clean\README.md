# Clean Mu-Silicium j6lte baseline

This overlay reproduces the user's known-booting port process exactly:

1. copy/rename `gtaxllte` to `j6lte`;
2. change the visible model name to `Galaxy J6`;
3. change framebuffer dimensions to `720 x 1480`.

No other platform values are modified. In particular:

- the gtaxllte memory map is unchanged;
- the display reservation remains `0x01194000`;
- no touch MMIO descriptors are added;
- the original S5E7870 ACPI tables are unchanged;
- no touchscreen ACPI device is added.

The root-enumerated V3 WinPE handles touchscreen creation independently, so
this firmware stays equivalent to the already proven booting baseline.

Apply to an initialized Mu-Silicium checkout:

```powershell
powershell -ExecutionPolicy Bypass -File .\apply-overlay.ps1 `
  -MuRoot C:\path\to\Mu-Silicium
```

Build:

```console
python build_uefi.py -d j6lte -r RELEASE -c
```
