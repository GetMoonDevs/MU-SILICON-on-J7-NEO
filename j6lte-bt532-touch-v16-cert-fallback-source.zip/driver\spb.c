#include "driver.h"

// Fixed j6lte S5E7870 resources.  These addresses are supplied by the j6lte
// Mu-Silicium DSDT as translated memory resources; they are not mapped by
// hard-coded physical access behind Plug and Play's back.
#define J6_TOUCH_I2C_PHYSICAL       0x13890000ULL
#define J6_PERI_CLOCK_PHYSICAL      0x101F0000ULL
#define J6_NFC_GPIO_PHYSICAL        0x139C0000ULL
#define J6_PMIC_I2C_PHYSICAL        0x10510000ULL
#define J6_MIF_CLOCK_PHYSICAL       0x10460000ULL
#define J6_MIF_GPIO_PHYSICAL        0x10530000ULL
#define J6_ALIVE_GPIO_PHYSICAL      0x139F0000ULL

#define J6_ZT7548_I2C_ADDRESS       0x20
#define J6_S2MPU05_I2C_ADDRESS      0x66
#define J6_S2MPU05_L34CTRL          0x50
#define J6_S2MPU05_L34_3V3_ON       0xFC

// CMU_PERI / CMU_MIF clock gates.
#define CMU_PERI_GATE0              0x0810
#define CMU_PERI_BUS_HCLK           (1UL << 3)
#define CMU_PERI_I2C6_PCLK          (1UL << 19)
#define CMU_MIF_HSI2C_PCLKS         0x0828
#define CMU_MIF_HSI2C_PCLKS_AP      (1UL << 14)
#define CMU_MIF_HSI2C_PCLKM         0x0840
#define CMU_MIF_HSI2C_PCLKM_AP      (1UL << 0)
#define CMU_MIF_HSI2C_IPCLK         (1UL << 2)
#define CMU_MIF_HSI2C_ITCLK         (1UL << 3)
#define CMU_MIF_PERI_BUS_GATE       0x08A0
#define CMU_MIF_PERI_BUS_ON         (1UL << 0)

// Exynos GPIO bank layout.
#define GPIO_CON                    0x00
#define GPIO_DAT                    0x04
#define GPIO_PUD                    0x08
#define GPIO_DRV                    0x0C
#define GPIO_GPA0_OFFSET            0x40
#define GPIO_TOUCH_IRQ_PIN          6

// S3C2440-compatible legacy I2C controller.
#define S3C_IICCON                  0x00
#define S3C_IICSTAT                 0x04
#define S3C_IICADD                  0x08
#define S3C_IICDS                   0x0C
#define S3C_IICLC                   0x10

#define S3C_IICCON_ACKEN            (1UL << 7)
#define S3C_IICCON_TXDIV_512        (1UL << 6)
#define S3C_IICCON_IRQEN            (1UL << 5)
#define S3C_IICCON_IRQPEND          (1UL << 4)
#define S3C_IICCON_SCALE(x)         ((x) & 0xFUL)

#define S3C_IICSTAT_MASTER_RX       (2UL << 6)
#define S3C_IICSTAT_MASTER_TX       (3UL << 6)
#define S3C_IICSTAT_START           (1UL << 5)
#define S3C_IICSTAT_BUSBUSY         (1UL << 5)
#define S3C_IICSTAT_TXRXEN          (1UL << 4)
#define S3C_IICSTAT_ARBITR          (1UL << 3)
#define S3C_IICSTAT_LASTBIT         (1UL << 0)

#define S3C_IICLC_SDA_DELAY10       (2UL << 0)
#define S3C_IICLC_FILTER_ON         (1UL << 2)

// Exynos high-speed I2C controller used by S2MPU05.
#define HSI2C_CTRL                  0x000
#define HSI2C_FIFO_CTRL             0x004
#define HSI2C_TRAIL_CTRL            0x008
#define HSI2C_INT_ENABLE            0x020
#define HSI2C_INT_STATUS            0x024
#define HSI2C_FIFO_STATUS           0x030
#define HSI2C_TX_DATA               0x034
#define HSI2C_RX_DATA               0x038
#define HSI2C_CONF                  0x040
#define HSI2C_AUTO_CONF             0x044
#define HSI2C_TIMEOUT               0x048
#define HSI2C_TRANS_STATUS          0x050
#define HSI2C_TIMING_FS1            0x060
#define HSI2C_TIMING_FS2            0x064
#define HSI2C_TIMING_FS3            0x068
#define HSI2C_ADDRESS               0x070

#define HSI2C_MASTER                (1UL << 3)
#define HSI2C_RXCHON                (1UL << 6)
#define HSI2C_TXCHON                (1UL << 7)
#define HSI2C_SW_RST                (1UL << 31)
#define HSI2C_AUTO_MODE             (1UL << 31)
#define HSI2C_HS_MODE               (1UL << 29)
#define HSI2C_10BIT_ADDR_MODE       (1UL << 30)
#define HSI2C_TIMEOUT_EN            (1UL << 31)
#define HSI2C_RXFIFO_EN             (1UL << 0)
#define HSI2C_TXFIFO_EN             (1UL << 1)
#define HSI2C_RXFIFO_TRIGGER(x)     ((x) << 4)
#define HSI2C_TXFIFO_TRIGGER(x)     ((x) << 16)
#define HSI2C_READ_WRITE            (1UL << 16)
#define HSI2C_STOP_AFTER_TRANS      (1UL << 17)
#define HSI2C_MASTER_RUN            (1UL << 31)
#define HSI2C_INT_TRANSFER_DONE     (1UL << 7)
#define HSI2C_INT_NO_DEVICE         (1UL << 10)
#define HSI2C_INT_ERROR_MASK        (15UL << 8)
#define HSI2C_TX_FIFO_LEVEL_MASK    0x7FUL
#define HSI2C_TX_FIFO_EMPTY         (1UL << 8)
#define HSI2C_RX_FIFO_EMPTY         (1UL << 24)

#define J6_LEGACY_I2C_TIMEOUT_US    10000UL
#define J6_HSI2C_TIMEOUT_US         100000UL
#define J6_TRANSFER_RETRIES         3UL

static
ULONG
MmioRead32(
    _In_ PUCHAR Base,
    _In_ ULONG Offset
    )
{
    return READ_REGISTER_ULONG((PULONG)(Base + Offset));
}

static
VOID
MmioWrite32(
    _In_ PUCHAR Base,
    _In_ ULONG Offset,
    _In_ ULONG Value
    )
{
    WRITE_REGISTER_ULONG((PULONG)(Base + Offset), Value);
}

static
VOID
MmioSetBits(
    _In_ PUCHAR Base,
    _In_ ULONG Offset,
    _In_ ULONG Bits
    )
{
    MmioWrite32(Base, Offset, MmioRead32(Base, Offset) | Bits);
}

static
VOID
MmioUpdateBits(
    _In_ PUCHAR Base,
    _In_ ULONG Offset,
    _In_ ULONG Mask,
    _In_ ULONG Value
    )
{
    ULONG current = MmioRead32(Base, Offset);

    current &= ~Mask;
    current |= Value & Mask;
    MmioWrite32(Base, Offset, current);
}

static
NTSTATUS
MapResource(
    _Inout_ PUCHAR* Base,
    _Out_ ULONG* MappedLength,
    _In_ PCM_PARTIAL_RESOURCE_DESCRIPTOR Resource
    )
{
    if (*Base != NULL) {
        return STATUS_DEVICE_CONFIGURATION_ERROR;
    }

    *Base = (PUCHAR)MmMapIoSpaceEx(
        Resource->u.Memory.Start,
        Resource->u.Memory.Length,
        PAGE_READWRITE | PAGE_NOCACHE);
    if (*Base == NULL) {
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    *MappedLength = Resource->u.Memory.Length;
    return STATUS_SUCCESS;
}

static
NTSTATUS
MapFixedResource(
    _Inout_ PUCHAR* Base,
    _Inout_ ULONG* MappedLength,
    _In_ ULONGLONG PhysicalAddress,
    _In_ ULONG Length
    )
{
    PHYSICAL_ADDRESS address;

    if (*Base != NULL) {
        return STATUS_SUCCESS;
    }

    address.QuadPart = (LONGLONG)PhysicalAddress;
    *Base = (PUCHAR)MmMapIoSpaceEx(
        address,
        Length,
        PAGE_READWRITE | PAGE_NOCACHE);
    if (*Base == NULL) {
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    *MappedLength = Length;
    return STATUS_SUCCESS;
}

static
VOID
UnmapResource(
    _Inout_ PUCHAR* Base,
    _Inout_ ULONG* MappedLength
    )
{
    if (*Base != NULL) {
        MmUnmapIoSpace(*Base, *MappedLength);
        *Base = NULL;
        *MappedLength = 0;
    }
}

static
VOID
ConfigureClocksAndPins(
    _Inout_ PDEVICE_CONTEXT Context
    )
{
    // Keep the PERI parent and the legacy I2C6 leaf clock running.
    MmioSetBits(
        Context->MifClockRegisters,
        CMU_MIF_PERI_BUS_GATE,
        CMU_MIF_PERI_BUS_ON);
    MmioSetBits(
        Context->PeriClockRegisters,
        CMU_PERI_GATE0,
        CMU_PERI_BUS_HCLK | CMU_PERI_I2C6_PCLK);

    // HSI2C0 clocks are needed only to turn on the touchscreen's PMIC rail.
    MmioSetBits(
        Context->MifClockRegisters,
        CMU_MIF_HSI2C_PCLKS,
        CMU_MIF_HSI2C_PCLKS_AP);
    MmioSetBits(
        Context->MifClockRegisters,
        CMU_MIF_HSI2C_PCLKM,
        CMU_MIF_HSI2C_PCLKM_AP |
        CMU_MIF_HSI2C_IPCLK |
        CMU_MIF_HSI2C_ITCLK);

    // I2C6 is on GPC2-0/1 in the NFC pin controller.  Function 2 selects
    // SCL/SDA.  Do not enable internal pulls; the board has external pulls.
    MmioUpdateBits(Context->NfcGpioRegisters, GPIO_CON, 0xFF, 0x22);
    MmioUpdateBits(Context->NfcGpioRegisters, GPIO_PUD, 0x0F, 0);
    MmioUpdateBits(Context->NfcGpioRegisters, GPIO_DRV, 0x3F, 0);

    // PMIC HSI2C0 is on GPM0-0/1, also function 2.
    MmioUpdateBits(Context->MifGpioRegisters, GPIO_CON, 0xFF, 0x22);
    MmioUpdateBits(Context->MifGpioRegisters, GPIO_PUD, 0x0F, 0);
    MmioUpdateBits(Context->MifGpioRegisters, GPIO_DRV, 0x3F, 0);

    // Poll GPA0-6 as a plain input.  The ZT7548 interrupt is active-low.
    MmioUpdateBits(
        Context->AliveGpioRegisters,
        GPIO_GPA0_OFFSET + GPIO_CON,
        0xFUL << (GPIO_TOUCH_IRQ_PIN * 4),
        0);
    MmioUpdateBits(
        Context->AliveGpioRegisters,
        GPIO_GPA0_OFFSET + GPIO_PUD,
        0x3UL << (GPIO_TOUCH_IRQ_PIN * 2),
        0);
}

static
VOID
LegacyI2cInitialize(
    _Inout_ PDEVICE_CONTEXT Context
    )
{
    PUCHAR base = Context->TouchI2cRegisters;

    // A conservative divider works independently of the exact retained PERI
    // parent rate and remains safely below the ZT7548's 400-kHz maximum.
    MmioWrite32(base, S3C_IICCON, S3C_IICCON_TXDIV_512 | S3C_IICCON_SCALE(0));
    MmioWrite32(base, S3C_IICSTAT, 0);
    MmioWrite32(base, S3C_IICADD, 0);
    MmioWrite32(base, S3C_IICLC, S3C_IICLC_FILTER_ON | S3C_IICLC_SDA_DELAY10);
}

static
NTSTATUS
LegacyWaitPending(
    _In_ PDEVICE_CONTEXT Context
    )
{
    ULONG elapsed;

    for (elapsed = 0; elapsed < J6_LEGACY_I2C_TIMEOUT_US; ++elapsed) {
        if ((MmioRead32(Context->TouchI2cRegisters, S3C_IICCON) &
             S3C_IICCON_IRQPEND) != 0) {
            return STATUS_SUCCESS;
        }
        KeStallExecutionProcessor(1);
    }

    return STATUS_IO_TIMEOUT;
}

static
VOID
LegacyClearPending(
    _In_ PDEVICE_CONTEXT Context
    )
{
    ULONG control = MmioRead32(Context->TouchI2cRegisters, S3C_IICCON);

    MmioWrite32(
        Context->TouchI2cRegisters,
        S3C_IICCON,
        control & ~S3C_IICCON_IRQPEND);
}

static
VOID
LegacyStop(
    _In_ PDEVICE_CONTEXT Context
    )
{
    PUCHAR base = Context->TouchI2cRegisters;
    ULONG elapsed;
    ULONG status;
    ULONG control;

    status = MmioRead32(base, S3C_IICSTAT);
    MmioWrite32(base, S3C_IICSTAT, status & ~S3C_IICSTAT_START);
    LegacyClearPending(Context);

    for (elapsed = 0; elapsed < 5000; ++elapsed) {
        if ((MmioRead32(base, S3C_IICSTAT) & S3C_IICSTAT_BUSBUSY) == 0) {
            break;
        }
        KeStallExecutionProcessor(1);
    }

    status = MmioRead32(base, S3C_IICSTAT);
    MmioWrite32(base, S3C_IICSTAT, status & ~S3C_IICSTAT_TXRXEN);

    control = MmioRead32(base, S3C_IICCON);
    control &= ~(S3C_IICCON_IRQEN | S3C_IICCON_IRQPEND | S3C_IICCON_ACKEN);
    MmioWrite32(base, S3C_IICCON, control);
}

static
NTSTATUS
LegacyBegin(
    _In_ PDEVICE_CONTEXT Context,
    _In_ BOOLEAN Read
    )
{
    PUCHAR base = Context->TouchI2cRegisters;
    ULONG address;
    ULONG control;
    ULONG elapsed;
    ULONG status;
    NTSTATUS result;

    for (elapsed = 0; elapsed < 5000; ++elapsed) {
        if ((MmioRead32(base, S3C_IICSTAT) & S3C_IICSTAT_BUSBUSY) == 0) {
            break;
        }
        KeStallExecutionProcessor(1);
    }
    if (elapsed == 5000) {
        return STATUS_DEVICE_BUSY;
    }

    control = S3C_IICCON_ACKEN |
              S3C_IICCON_TXDIV_512 |
              S3C_IICCON_IRQEN |
              S3C_IICCON_SCALE(0);
    status = S3C_IICSTAT_TXRXEN |
             (Read ? S3C_IICSTAT_MASTER_RX : S3C_IICSTAT_MASTER_TX);
    address = (J6_ZT7548_I2C_ADDRESS << 1) | (Read ? 1UL : 0UL);

    MmioWrite32(base, S3C_IICCON, control);
    MmioWrite32(base, S3C_IICSTAT, status);
    MmioWrite32(base, S3C_IICDS, address);
    KeStallExecutionProcessor(1);
    MmioWrite32(base, S3C_IICCON, control);
    MmioWrite32(base, S3C_IICSTAT, status | S3C_IICSTAT_START);

    result = LegacyWaitPending(Context);
    if (!NT_SUCCESS(result)) {
        LegacyStop(Context);
        return result;
    }

    status = MmioRead32(base, S3C_IICSTAT);
    if ((status & S3C_IICSTAT_ARBITR) != 0) {
        LegacyStop(Context);
        return STATUS_DEVICE_BUSY;
    }
    if ((status & S3C_IICSTAT_LASTBIT) != 0) {
        LegacyStop(Context);
        return STATUS_DEVICE_NOT_CONNECTED;
    }

    return STATUS_SUCCESS;
}

static
NTSTATUS
LegacyWriteOnce(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_reads_bytes_(Length) const UCHAR* Buffer,
    _In_ ULONG Length
    )
{
    PUCHAR base = Context->TouchI2cRegisters;
    ULONG index;
    ULONG status;
    NTSTATUS result;

    result = LegacyBegin(Context, FALSE);
    if (!NT_SUCCESS(result)) {
        return result;
    }

    for (index = 0; index < Length; ++index) {
        MmioWrite32(base, S3C_IICDS, Buffer[index]);
        KeStallExecutionProcessor(1);
        LegacyClearPending(Context);

        result = LegacyWaitPending(Context);
        if (!NT_SUCCESS(result)) {
            LegacyStop(Context);
            return result;
        }

        status = MmioRead32(base, S3C_IICSTAT);
        if ((status & S3C_IICSTAT_ARBITR) != 0) {
            LegacyStop(Context);
            return STATUS_DEVICE_BUSY;
        }
        if ((status & S3C_IICSTAT_LASTBIT) != 0) {
            LegacyStop(Context);
            return STATUS_DEVICE_NOT_CONNECTED;
        }
    }

    LegacyStop(Context);
    return STATUS_SUCCESS;
}

static
NTSTATUS
LegacyReadOnce(
    _Inout_ PDEVICE_CONTEXT Context,
    _Out_writes_bytes_(Length) UCHAR* Buffer,
    _In_ ULONG Length
    )
{
    PUCHAR base = Context->TouchI2cRegisters;
    ULONG control;
    ULONG index;
    NTSTATUS result;

    result = LegacyBegin(Context, TRUE);
    if (!NT_SUCCESS(result)) {
        return result;
    }

    for (index = 0; index < Length; ++index) {
        if (index + 1 == Length) {
            control = MmioRead32(base, S3C_IICCON);
            MmioWrite32(base, S3C_IICCON, control & ~S3C_IICCON_ACKEN);
        }

        LegacyClearPending(Context);
        result = LegacyWaitPending(Context);
        if (!NT_SUCCESS(result)) {
            LegacyStop(Context);
            return result;
        }

        Buffer[index] = (UCHAR)MmioRead32(base, S3C_IICDS);
    }

    LegacyStop(Context);
    return STATUS_SUCCESS;
}

static
NTSTATUS
LegacyWriteLocked(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_reads_bytes_(Length) const UCHAR* Buffer,
    _In_ ULONG Length
    )
{
    ULONG attempt;
    NTSTATUS status = STATUS_UNSUCCESSFUL;

    if (!Context->HardwarePrepared || Buffer == NULL || Length == 0) {
        return STATUS_INVALID_DEVICE_STATE;
    }

    for (attempt = 0; attempt < J6_TRANSFER_RETRIES; ++attempt) {
        status = LegacyWriteOnce(Context, Buffer, Length);
        if (NT_SUCCESS(status)) {
            return status;
        }
        LegacyI2cInitialize(Context);
        KeStallExecutionProcessor(100);
    }

    return status;
}

static
NTSTATUS
LegacyReadLocked(
    _Inout_ PDEVICE_CONTEXT Context,
    _Out_writes_bytes_(Length) UCHAR* Buffer,
    _In_ ULONG Length
    )
{
    ULONG attempt;
    NTSTATUS status = STATUS_UNSUCCESSFUL;

    if (!Context->HardwarePrepared || Buffer == NULL || Length == 0) {
        return STATUS_INVALID_DEVICE_STATE;
    }

    RtlZeroMemory(Buffer, Length);
    for (attempt = 0; attempt < J6_TRANSFER_RETRIES; ++attempt) {
        status = LegacyReadOnce(Context, Buffer, Length);
        if (NT_SUCCESS(status)) {
            return status;
        }
        LegacyI2cInitialize(Context);
        KeStallExecutionProcessor(100);
    }

    return status;
}

static
VOID
Hsi2cInitialize(
    _In_ PDEVICE_CONTEXT Context
    )
{
    PUCHAR base = Context->PmicI2cRegisters;
    ULONG config;
    ULONG control;

    control = MmioRead32(base, HSI2C_CTRL);
    MmioWrite32(base, HSI2C_CTRL, control | HSI2C_SW_RST);
    MmioWrite32(base, HSI2C_CTRL, control & ~HSI2C_SW_RST);

    // Conservative 400-kHz timing for the approximately 200-MHz HSI2C input.
    // If firmware retained a lower parent rate, the resulting bus is slower,
    // which remains valid for S2MPU05.
    MmioUpdateBits(base, HSI2C_TIMING_FS3, 0x00FF0000, 33UL << 16);
    MmioUpdateBits(base, HSI2C_TIMING_FS2, 0x000000FF, 0xE0);
    MmioUpdateBits(base, HSI2C_TIMING_FS1, 0x00FF0000, 0xF0UL << 16);

    MmioWrite32(base, HSI2C_CTRL, HSI2C_MASTER);
    MmioWrite32(base, HSI2C_TRAIL_CTRL, 0x00FFFFFF);

    config = MmioRead32(base, HSI2C_CONF);
    config &= ~(HSI2C_HS_MODE | HSI2C_10BIT_ADDR_MODE);
    config |= HSI2C_AUTO_MODE;
    MmioWrite32(base, HSI2C_CONF, config);
}

static
NTSTATUS
Hsi2cWriteOnce(
    _In_ PDEVICE_CONTEXT Context,
    _In_reads_bytes_(Length) const UCHAR* Buffer,
    _In_ ULONG Length,
    _In_ BOOLEAN Stop
    )
{
    PUCHAR base = Context->PmicI2cRegisters;
    ULONG address;
    ULONG autoConfig;
    ULONG fifoControl;
    ULONG fifoStatus;
    ULONG index = 0;
    ULONG interruptStatus;
    ULONG timeout;
    ULONG trigger;

    if (Length == 0 || Length > 64) {
        return STATUS_INVALID_PARAMETER;
    }

    MmioUpdateBits(base, HSI2C_TIMEOUT, HSI2C_TIMEOUT_EN, 0);
    interruptStatus = MmioRead32(base, HSI2C_INT_STATUS);
    MmioWrite32(base, HSI2C_INT_STATUS, interruptStatus);

    trigger = min(Length, 8UL);
    fifoControl = HSI2C_RXFIFO_EN |
                  HSI2C_TXFIFO_EN |
                  HSI2C_RXFIFO_TRIGGER(trigger) |
                  HSI2C_TXFIFO_TRIGGER(trigger);
    MmioWrite32(base, HSI2C_FIFO_CTRL, fifoControl);
    MmioUpdateBits(base, HSI2C_CTRL, HSI2C_RXCHON | HSI2C_TXCHON, HSI2C_TXCHON);

    address = MmioRead32(base, HSI2C_ADDRESS);
    address &= ~((0x3FFUL << 10) | 0x3FFUL | (0xFFUL << 24));
    address |= (J6_S2MPU05_I2C_ADDRESS & 0x7FUL) << 10;
    MmioWrite32(base, HSI2C_ADDRESS, address);

    autoConfig = MmioRead32(base, HSI2C_AUTO_CONF);
    autoConfig &= ~(HSI2C_MASTER_RUN |
                    HSI2C_READ_WRITE |
                    HSI2C_STOP_AFTER_TRANS |
                    0xFFFFUL);
    autoConfig |= Stop ? HSI2C_STOP_AFTER_TRANS : 0;
    autoConfig |= Length & 0xFFFFUL;
    MmioWrite32(base, HSI2C_AUTO_CONF, autoConfig);
    MmioWrite32(base, HSI2C_INT_ENABLE, HSI2C_INT_TRANSFER_DONE);
    MmioSetBits(base, HSI2C_AUTO_CONF, HSI2C_MASTER_RUN);

    for (timeout = 0; timeout < J6_HSI2C_TIMEOUT_US && index < Length; ++timeout) {
        fifoStatus = MmioRead32(base, HSI2C_FIFO_STATUS);
        if ((fifoStatus & HSI2C_TX_FIFO_LEVEL_MASK) < 16) {
            MmioWrite32(base, HSI2C_TX_DATA, Buffer[index++]);
        }
        KeStallExecutionProcessor(1);
    }

    for (; timeout < J6_HSI2C_TIMEOUT_US; ++timeout) {
        interruptStatus = MmioRead32(base, HSI2C_INT_STATUS);
        fifoStatus = MmioRead32(base, HSI2C_FIFO_STATUS);
        if ((interruptStatus & HSI2C_INT_TRANSFER_DONE) != 0 &&
            (fifoStatus & HSI2C_TX_FIFO_EMPTY) != 0) {
            MmioWrite32(base, HSI2C_INT_STATUS, interruptStatus);
            return STATUS_SUCCESS;
        }
        if ((interruptStatus & HSI2C_INT_NO_DEVICE) != 0) {
            MmioWrite32(base, HSI2C_INT_STATUS, interruptStatus);
            return STATUS_DEVICE_NOT_CONNECTED;
        }
        if ((interruptStatus & HSI2C_INT_ERROR_MASK) != 0 &&
            (interruptStatus & HSI2C_INT_TRANSFER_DONE) == 0) {
            MmioWrite32(base, HSI2C_INT_STATUS, interruptStatus);
            return STATUS_IO_DEVICE_ERROR;
        }
        KeStallExecutionProcessor(1);
    }

    return STATUS_IO_TIMEOUT;
}

static
NTSTATUS
EnableTouchPowerRail(
    _In_ PDEVICE_CONTEXT Context
    )
{
    UCHAR packet[2];
    ULONG attempt;
    NTSTATUS status = STATUS_UNSUCCESSFUL;

    packet[0] = J6_S2MPU05_L34CTRL;
    packet[1] = J6_S2MPU05_L34_3V3_ON;

    Hsi2cInitialize(Context);
    for (attempt = 0; attempt < J6_TRANSFER_RETRIES; ++attempt) {
        status = Hsi2cWriteOnce(Context, packet, sizeof(packet), TRUE);
        if (NT_SUCCESS(status)) {
            KeStallExecutionProcessor(500);
            return status;
        }
        Hsi2cInitialize(Context);
        KeStallExecutionProcessor(100);
    }

    return status;
}

NTSTATUS
SpbTargetOpen(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ WDFCMRESLIST ResourcesTranslated
    )
{
    PCM_PARTIAL_RESOURCE_DESCRIPTOR resource;
    ULONGLONG start;
    ULONG count;
    ULONG index;
    NTSTATUS status = STATUS_SUCCESS;
    NTSTATUS powerStatus;
    BOOLEAN suppliedByPnp = FALSE;

    Context->HardwarePrepared = FALSE;
    count = WdfCmResourceListGetCount(ResourcesTranslated);
    for (index = 0; index < count; ++index) {
        resource = WdfCmResourceListGetDescriptor(ResourcesTranslated, index);
        if (resource == NULL || resource->Type != CmResourceTypeMemory) {
            continue;
        }

        start = (ULONGLONG)resource->u.Memory.Start.QuadPart;
        switch (start) {
        case J6_TOUCH_I2C_PHYSICAL:
            suppliedByPnp = TRUE;
            status = MapResource(
                &Context->TouchI2cRegisters,
                &Context->TouchI2cRegistersLength,
                resource);
            break;
        case J6_PERI_CLOCK_PHYSICAL:
            status = MapResource(
                &Context->PeriClockRegisters,
                &Context->PeriClockRegistersLength,
                resource);
            break;
        case J6_NFC_GPIO_PHYSICAL:
            status = MapResource(
                &Context->NfcGpioRegisters,
                &Context->NfcGpioRegistersLength,
                resource);
            break;
        case J6_PMIC_I2C_PHYSICAL:
            status = MapResource(
                &Context->PmicI2cRegisters,
                &Context->PmicI2cRegistersLength,
                resource);
            break;
        case J6_MIF_CLOCK_PHYSICAL:
            status = MapResource(
                &Context->MifClockRegisters,
                &Context->MifClockRegistersLength,
                resource);
            break;
        case J6_MIF_GPIO_PHYSICAL:
            status = MapResource(
                &Context->MifGpioRegisters,
                &Context->MifGpioRegistersLength,
                resource);
            break;
        case J6_ALIVE_GPIO_PHYSICAL:
            status = MapResource(
                &Context->AliveGpioRegisters,
                &Context->AliveGpioRegistersLength,
                resource);
            break;
        default:
            break;
        }

        if (!NT_SUCCESS(status)) {
            J6_TRACE_ERROR(
                "J6ZT7548: failed to map MMIO resource 0x%llX: 0x%08X\n",
                start,
                status);
            SpbTargetClose(Context);
            return status;
        }
    }

    // The known-booting gtaxllte-derived Mu-Silicium firmware has no touch
    // ACPI node. WinPE therefore creates ROOT\J6ZT7548 and this board-specific
    // fallback maps the same fixed SoC windows that a complete j6lte DSDT
    // would assign. Keeping this fallback in one place makes its scope clear.
    status = MapFixedResource(
        &Context->TouchI2cRegisters,
        &Context->TouchI2cRegistersLength,
        J6_TOUCH_I2C_PHYSICAL,
        0x100);
    if (NT_SUCCESS(status)) {
        status = MapFixedResource(
            &Context->PeriClockRegisters,
            &Context->PeriClockRegistersLength,
            J6_PERI_CLOCK_PHYSICAL,
            0x1000);
    }
    if (NT_SUCCESS(status)) {
        status = MapFixedResource(
            &Context->NfcGpioRegisters,
            &Context->NfcGpioRegistersLength,
            J6_NFC_GPIO_PHYSICAL,
            0x1000);
    }
    if (NT_SUCCESS(status)) {
        status = MapFixedResource(
            &Context->PmicI2cRegisters,
            &Context->PmicI2cRegistersLength,
            J6_PMIC_I2C_PHYSICAL,
            0x2000);
    }
    if (NT_SUCCESS(status)) {
        status = MapFixedResource(
            &Context->MifClockRegisters,
            &Context->MifClockRegistersLength,
            J6_MIF_CLOCK_PHYSICAL,
            0x1000);
    }
    if (NT_SUCCESS(status)) {
        status = MapFixedResource(
            &Context->MifGpioRegisters,
            &Context->MifGpioRegistersLength,
            J6_MIF_GPIO_PHYSICAL,
            0x1000);
    }
    if (NT_SUCCESS(status)) {
        status = MapFixedResource(
            &Context->AliveGpioRegisters,
            &Context->AliveGpioRegistersLength,
            J6_ALIVE_GPIO_PHYSICAL,
            0x1000);
    }
    if (!NT_SUCCESS(status)) {
        J6_TRACE_ERROR(
            "J6ZT7548: failed to map fixed j6lte MMIO windows: 0x%08X\n",
            status);
        SpbTargetClose(Context);
        return status;
    }

    J6SetDiagnosticValue(Context, L"TransportMode", suppliedByPnp ? 1 : 2);
    J6SetDiagnosticValue(Context, L"MmioMapStatus", status);

    ConfigureClocksAndPins(Context);
    LegacyI2cInitialize(Context);
    Context->HardwarePrepared = TRUE;

    J6SetDiagnosticValue(
        Context,
        L"InitialGpa0Data",
        MmioRead32(Context->AliveGpioRegisters, GPIO_GPA0_OFFSET + GPIO_DAT));
    J6SetDiagnosticValue(
        Context,
        L"InitialTouchIicCon",
        MmioRead32(Context->TouchI2cRegisters, S3C_IICCON));
    J6SetDiagnosticValue(
        Context,
        L"InitialTouchIicStat",
        MmioRead32(Context->TouchI2cRegisters, S3C_IICSTAT));

    powerStatus = EnableTouchPowerRail(Context);
    J6SetDiagnosticValue(Context, L"Ldo34Status", powerStatus);
    J6SetDiagnosticValue(
        Context,
        L"PmicHsi2cIntStatus",
        MmioRead32(Context->PmicI2cRegisters, HSI2C_INT_STATUS));
    J6SetDiagnosticValue(
        Context,
        L"PmicHsi2cTransStatus",
        MmioRead32(Context->PmicI2cRegisters, HSI2C_TRANS_STATUS));
    if (!NT_SUCCESS(powerStatus)) {
        // Some bootloader revisions leave LDO34 enabled.  Continue to the
        // definitive ZT7548 chip-code probe rather than rejecting that case.
        J6_TRACE_ERROR(
            "J6ZT7548: LDO34 enable transaction failed: 0x%08X; probing touch anyway\n",
            powerStatus);
    }

    return STATUS_SUCCESS;
}

VOID
SpbTargetClose(
    _Inout_ PDEVICE_CONTEXT Context
    )
{
    Context->HardwarePrepared = FALSE;

    UnmapResource(&Context->AliveGpioRegisters, &Context->AliveGpioRegistersLength);
    UnmapResource(&Context->MifGpioRegisters, &Context->MifGpioRegistersLength);
    UnmapResource(&Context->MifClockRegisters, &Context->MifClockRegistersLength);
    UnmapResource(&Context->PmicI2cRegisters, &Context->PmicI2cRegistersLength);
    UnmapResource(&Context->NfcGpioRegisters, &Context->NfcGpioRegistersLength);
    UnmapResource(&Context->PeriClockRegisters, &Context->PeriClockRegistersLength);
    UnmapResource(&Context->TouchI2cRegisters, &Context->TouchI2cRegistersLength);
}

BOOLEAN
SpbTouchInterruptAsserted(
    _In_ PDEVICE_CONTEXT Context
    )
{
    ULONG value;

    if (!Context->HardwarePrepared || Context->AliveGpioRegisters == NULL) {
        return FALSE;
    }

    value = MmioRead32(
        Context->AliveGpioRegisters,
        GPIO_GPA0_OFFSET + GPIO_DAT);
    return (value & (1UL << GPIO_TOUCH_IRQ_PIN)) == 0;
}

NTSTATUS
SpbWrite(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_reads_bytes_(Length) const UCHAR* Buffer,
    _In_ ULONG Length
    )
{
    NTSTATUS status;

    status = WdfWaitLockAcquire(Context->SpbLock, NULL);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    status = LegacyWriteLocked(Context, Buffer, Length);
    if (NT_SUCCESS(status)) {
        KeStallExecutionProcessor(10);
    }

    WdfWaitLockRelease(Context->SpbLock);
    return status;
}

NTSTATUS
SpbWriteRead(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_reads_bytes_(WriteLength) const UCHAR* WriteBuffer,
    _In_ ULONG WriteLength,
    _Out_writes_bytes_(ReadLength) UCHAR* ReadBuffer,
    _In_ ULONG ReadLength
    )
{
    NTSTATUS status;

    status = WdfWaitLockAcquire(Context->SpbLock, NULL);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    // Samsung's ZT7548 firmware requires a STOP between the register pointer
    // write and the receive operation, plus a short latch delay.
    status = LegacyWriteLocked(Context, WriteBuffer, WriteLength);
    if (NT_SUCCESS(status)) {
        KeStallExecutionProcessor(50);
        status = LegacyReadLocked(Context, ReadBuffer, ReadLength);
        if (NT_SUCCESS(status)) {
            KeStallExecutionProcessor(10);
        }
    }

    WdfWaitLockRelease(Context->SpbLock);
    return status;
}
