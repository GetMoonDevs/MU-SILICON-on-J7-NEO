[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$PackageDirectory,

    [string]$CertificatePath,

    [switch]$ForceNonArm64
)

$ErrorActionPreference = 'Stop'

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this script from an elevated PowerShell session on the target phone.'
}

$architecture = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
if ($architecture -ne 'Arm64' -and -not $ForceNonArm64) {
    throw "Target OS architecture is $architecture, not Arm64."
}

$inf = Get-ChildItem -Path $PackageDirectory -Filter 'J6LteBt532Touch.inf' -Recurse |
    Where-Object {
        Test-Path (Join-Path $_.DirectoryName 'J6LteBt532Touch.sys') -and
        Test-Path (Join-Path $_.DirectoryName 'j6ltebt532touch.cat')
    } |
    Select-Object -First 1
if (-not $inf) {
    throw "A complete J6LteBt532Touch INF/SYS/CAT package was not found under $PackageDirectory."
}

if (-not $CertificatePath) {
    $bundledCertificate = Join-Path $inf.DirectoryName 'J6LteBt532Touch.cer'
    if (Test-Path $bundledCertificate) {
        $CertificatePath = $bundledCertificate
    }
}

if ($CertificatePath) {
    if (-not (Test-Path $CertificatePath)) {
        throw "Certificate was not found: $CertificatePath"
    }

    Write-Warning 'Trusting the WDK test certificate on this development target.'
    Import-Certificate -FilePath $CertificatePath -CertStoreLocation 'Cert:\LocalMachine\Root' | Out-Null
    try {
        Import-Certificate -FilePath $CertificatePath -CertStoreLocation 'Cert:\LocalMachine\TrustedPublisher' |
            Out-Null
    } catch {
        $warning = "TrustedPublisher was not updated ({0}). ROOT trust succeeded; " +
            "continuing on this TESTSIGNING-enabled development target."
        Write-Warning ($warning -f $_.Exception.Message)
    }
}

& pnputil.exe /add-driver $inf.FullName /install
if ($LASTEXITCODE -ne 0) {
    throw "pnputil failed with exit code $LASTEXITCODE."
}

Write-Host 'Driver staged. Restart the ACPI device or reboot the target.'
