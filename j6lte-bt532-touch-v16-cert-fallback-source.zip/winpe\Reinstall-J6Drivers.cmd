@echo off
rem  Re-run the J6 driver installation from the PE desktop.
setlocal EnableExtensions
set "ROOT=X:\J6Touch"
if not exist "%ROOT%\Install-J6Drivers.cmd" (
    echo Payload not found at %ROOT%
    echo.
    pause
    exit /b 1
)
call "%ROOT%\Install-J6Drivers.cmd" %*
echo.
pause
