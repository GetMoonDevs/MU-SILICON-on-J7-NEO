#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wincrypt.h>
#include <stdio.h>

static BOOL
AddCertificateToStore(
    _In_z_ const WCHAR* StoreName,
    _In_reads_bytes_(CertificateLength) const BYTE* Certificate,
    _In_ DWORD CertificateLength
    )
{
    HCERTSTORE store;
    BOOL result;
    DWORD error;

    store = CertOpenStore(
        CERT_STORE_PROV_SYSTEM_W,
        0,
        0,
        CERT_SYSTEM_STORE_LOCAL_MACHINE | CERT_STORE_OPEN_EXISTING_FLAG,
        StoreName);
    if (store == NULL) {
        error = GetLastError();
        wprintf(
            L"CertOpenStore(%ls) failed: %lu (0x%08lX)\n",
            StoreName,
            error,
            error);
        return FALSE;
    }

    result = CertAddEncodedCertificateToStore(
        store,
        X509_ASN_ENCODING | PKCS_7_ASN_ENCODING,
        Certificate,
        CertificateLength,
        CERT_STORE_ADD_REPLACE_EXISTING,
        NULL);
    if (!result) {
        error = GetLastError();
        wprintf(
            L"CertAddEncodedCertificateToStore(%ls) failed: %lu (0x%08lX)\n",
            StoreName,
            error,
            error);
    }

    CertCloseStore(store, 0);
    return result;
}

int
wmain(
    int ArgumentCount,
    WCHAR** Arguments
    )
{
    HANDLE file;
    LARGE_INTEGER size;
    BYTE* certificate;
    DWORD bytesRead;
    BOOL rootAdded;
    BOOL publisherAdded;

    if (ArgumentCount != 2) {
        wprintf(L"Usage: J6TrustCert.exe certificate.cer\n");
        return 2;
    }

    file = CreateFileW(
        Arguments[1],
        GENERIC_READ,
        FILE_SHARE_READ,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL);
    if (file == INVALID_HANDLE_VALUE) {
        wprintf(L"CreateFile failed: %lu\n", GetLastError());
        return 3;
    }

    if (!GetFileSizeEx(file, &size) || size.QuadPart <= 0 || size.QuadPart > 65536) {
        wprintf(L"Invalid certificate size\n");
        CloseHandle(file);
        return 4;
    }

    certificate = (BYTE*)HeapAlloc(GetProcessHeap(), 0, (SIZE_T)size.QuadPart);
    if (certificate == NULL) {
        CloseHandle(file);
        return 5;
    }

    bytesRead = 0;
    if (!ReadFile(file, certificate, (DWORD)size.QuadPart, &bytesRead, NULL) ||
        bytesRead != (DWORD)size.QuadPart) {
        wprintf(L"ReadFile failed: %lu\n", GetLastError());
        HeapFree(GetProcessHeap(), 0, certificate);
        CloseHandle(file);
        return 6;
    }
    CloseHandle(file);

    rootAdded = AddCertificateToStore(L"ROOT", certificate, bytesRead);
    publisherAdded = AddCertificateToStore(
        L"TrustedPublisher",
        certificate,
        bytesRead);
    HeapFree(GetProcessHeap(), 0, certificate);

    if (!rootAdded) {
        wprintf(L"ERROR: the certificate was not added to LocalMachine\\ROOT.\n");
        return 7;
    }

    if (!publisherAdded) {
        /*
         * Some Windows 10 SetupComplete environments deny writes to the
         * LocalMachine TrustedPublisher store even while running as SYSTEM.
         * The package was already staged offline with /ForceUnsigned and the
         * target boots with TESTSIGNING enabled, so ROOT is the mandatory
         * store for this recovery/development workflow.  Do not prevent the
         * root-device helper from running solely because the optional
         * publisher store is locked down.
         */
        wprintf(
            L"WARNING: TrustedPublisher was not updated; ROOT trust succeeded. "
            L"Continuing in test-signing mode.\n");
        return 0;
    }

    wprintf(L"Test certificate trusted in ROOT and TrustedPublisher.\n");
    return 0;
}
