[CmdletBinding()]
param(
    [ValidateSet('Debug', 'Release')]
    [string]$Configuration = 'Release',

    [ValidateSet('ARM64', 'x64')]
    [string]$Platform = 'ARM64',

    [switch]$Rebuild
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$solution = Join-Path $root 'J6LteBt532Touch.sln'
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'

if (-not (Test-Path $vswhere)) {
    throw 'Visual Studio Installer (vswhere.exe) was not found.'
}

$installationPath = & $vswhere -latest -products * -requires Microsoft.Component.MSBuild -property installationPath
$msbuild = Join-Path $installationPath 'MSBuild\Current\Bin\amd64\MSBuild.exe'
if (-not (Test-Path $msbuild)) {
    $msbuild = & $vswhere -latest -products * -requires Microsoft.Component.MSBuild -find 'MSBuild\**\Bin\MSBuild.exe' | Select-Object -First 1
}
if (-not $msbuild -or -not (Test-Path $msbuild)) {
    throw 'MSBuild was not found in the Visual Studio installation.'
}

$target = if ($Rebuild) { 'Rebuild' } else { 'Build' }
& $msbuild $solution /m /t:$target /p:Configuration=$Configuration /p:Platform=$Platform /verbosity:minimal
if ($LASTEXITCODE -ne 0) {
    throw "Driver build failed with exit code $LASTEXITCODE."
}

$output = Join-Path $root "build\$Platform\$Configuration"
$package = Join-Path $output 'J6LteBt532Touch'
$certificate = Join-Path $output 'J6LteBt532Touch.cer'
if ((Test-Path $package) -and (Test-Path $certificate)) {
    Copy-Item $certificate $package -Force
}

$archive = Join-Path $output 'J6LteBt532Touch-arm64-test.zip'
if ($Platform -eq 'ARM64' -and (Test-Path $package)) {
    if (Test-Path $archive) {
        Remove-Item $archive -Force
    }
    Compress-Archive -Path (Join-Path $package '*') -DestinationPath $archive
    Write-Host "Test package archive: $archive"
}

Write-Host "Driver package output: $package"
