#requires -version 5.1
<#
    build-wdk19041.ps1 - build the ARM64 touch driver against the old
    Windows 10 2004 (10.0.19041) WDK, i.e. the toolchain that matches the
    Windows 10 IoT Enterprise LTSC 2021 (build 19044) target.

    Why this exists
    ---------------
    The default build (scripts\build.ps1 / MSBuild) uses the newest WDK that
    is installed, which here is 10.0.26100.  This script produces the same
    driver from the 19041 WDK headers, import libraries and the KMDF 1.15
    framework so the binary can be compared with the 26100 build.

    Requirements
    ------------
    * Visual Studio 2022 Build Tools with the ARM64 compiler (cl.exe).
    * A WDK 10.0.19041.685 "layout" download, extracted with
      msiexec /a (no administrator rights needed), providing:
          Include\10.0.19041.0\km
          Include\wdf\kmdf\1.15
          Lib\10.0.19041.0\km\arm64
          Lib\wdf\kmdf\arm64\1.15
    * Windows SDK headers for the SAL macros (specstrings.h).  Any installed
      SDK can supply Include\<ver>\shared.

    Usage
    -----
    powershell -ExecutionPolicy Bypass -File scripts\build-wdk19041.ps1 `
        -Wdk19041 'C:\path\to\extracted\Windows Kits\10' `
        -SdkShared 'C:\Program Files (x86)\Windows Kits\10\Include\10.0.26100.0\shared'

    The output lands in build\ARM64\wdk19041\ (SYS only; stamp and sign with
    scripts\pack-wdk19041.ps1, or reuse the normal MSBuild packaging).
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$Wdk19041,

    [Parameter(Mandatory = $true)]
    [string]$SdkShared,

    [string]$Configuration = 'Release'
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$sourceDir = Join-Path $root 'driver'
$outDir = Join-Path $root "build\ARM64\wdk19041"
$objDir = Join-Path $outDir 'obj'

foreach ($required in @(
    (Join-Path $Wdk19041 'Include\10.0.19041.0\km\ntddk.h'),
    (Join-Path $Wdk19041 'Include\wdf\kmdf\1.15\wdf.h'),
    (Join-Path $Wdk19041 'Lib\10.0.19041.0\km\arm64\ntoskrnl.lib'),
    (Join-Path $Wdk19041 'Lib\wdf\kmdf\arm64\1.15\wdfdriverentry.lib'),
    (Join-Path $SdkShared 'specstrings.h')
)) {
    if (-not (Test-Path $required)) { throw "Missing build input: $required" }
}

$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
if (-not (Test-Path $vswhere)) { throw 'Visual Studio Installer (vswhere.exe) was not found.' }
$installationPath = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.ARM64 -property installationPath
$msvcRoot = Get-ChildItem (Join-Path $installationPath 'VC\Tools\MSVC') -Directory |
    Sort-Object Name -Descending | Select-Object -First 1
$cl = Join-Path $msvcRoot.FullName 'bin\Hostx64\arm64\cl.exe'
$link = Join-Path $msvcRoot.FullName 'bin\Hostx64\arm64\link.exe'
if (-not (Test-Path $cl)) { throw "ARM64 cl.exe was not found under $($msvcRoot.FullName)." }

New-Item -ItemType Directory -Path $objDir -Force | Out-Null

$env:INCLUDE = @(
    (Join-Path $Wdk19041 'Include\wdf\kmdf\1.15'),
    (Join-Path $Wdk19041 'Include\10.0.19041.0\km\crt'),
    (Join-Path $Wdk19041 'Include\10.0.19041.0\km'),
    (Join-Path $Wdk19041 'Include\10.0.19041.0\shared'),
    $SdkShared
) -join ';'

$env:LIB = @(
    (Join-Path $Wdk19041 'Lib\wdf\kmdf\arm64\1.15'),
    (Join-Path $Wdk19041 'Lib\10.0.19041.0\km\arm64')
) -join ';'

$sources = @('driver.c', 'device.c', 'spb.c', 'bt532.c', 'hid.c')

# Mirrors the MSBuild DriverSettings from J6LteBt532Touch.vcxproj.
# /wd4324 is required because KMDF 1.15 headers trip it under /W4 /WX.
$compileArgs = @(
    '/nologo', '/c', '/kernel', '/GS-', '/W4', '/WX', '/O2', '/Oi', '/Gy',
    '/guard:cf', '/Zc:wchar_t-', '/Zc:inline',
    '/wd4324', '/wd4201', '/wd4100', '/wd4189',
    '/D_ARM64_=1', '/D_UNICODE', '/DUNICODE', '/DPOOL_NX_OPTIN=1'
)
if ($Configuration -eq 'Debug') {
    $compileArgs += @('/Od', '/DDBG=1', '/Zi')
} else {
    $compileArgs += @('/DNDEBUG')
}
# Compile from the driver directory so the source names stay space-free.
Push-Location $sourceDir
try {
    foreach ($source in $sources) {
        Write-Host "compiling $source"
        $objectPath = Join-Path $objDir ([IO.Path]::ChangeExtension($source, '.obj'))
        # Explicit quotes: the repository path contains a space.
        & $cl @compileArgs ('/Fo"' + $objectPath + '"') $source
        if ($LASTEXITCODE -ne 0) { throw "Compilation failed: $source" }
    }
} finally {
    Pop-Location
}

$objects = $sources | ForEach-Object { Join-Path $objDir ([IO.Path]::ChangeExtension($_, '.obj')) }
$sys = Join-Path $outDir 'J6LteBt532Touch.sys'

$linkArgs = @(
    '/nologo', '/DRIVER', '/SUBSYSTEM:NATIVE', '/MACHINE:ARM64',
    '/ENTRY:FxDriverEntry', "/OUT:$sys", '/INCREMENTAL:NO',
    '/OPT:REF', '/OPT:ICF', '/DYNAMICBASE', '/NXCOMPAT', '/HIGHENTROPYVA',
    '/GUARD:CF'
)
if ($Configuration -eq 'Release') { $linkArgs += @('/DEBUG:NONE', '/RELEASE') }
$linkArgs += $objects
$linkArgs += @(
    (Join-Path $Wdk19041 'Lib\wdf\kmdf\arm64\1.15\wdfdriverentry.lib'),
    (Join-Path $Wdk19041 'Lib\wdf\kmdf\arm64\1.15\wdfldr.lib'),
    (Join-Path $Wdk19041 'Lib\10.0.19041.0\km\arm64\BufferOverflowFastFailK.lib'),
    (Join-Path $Wdk19041 'Lib\10.0.19041.0\km\arm64\ntoskrnl.lib'),
    (Join-Path $Wdk19041 'Lib\10.0.19041.0\km\arm64\hal.lib'),
    (Join-Path $Wdk19041 'Lib\10.0.19041.0\km\arm64\wmilib.lib')
)

Write-Host 'linking J6LteBt532Touch.sys'
& $link @linkArgs
if ($LASTEXITCODE -ne 0) { throw 'Link failed.' }

$item = Get-Item $sys
Write-Host ("Built {0} ({1} bytes)" -f $item.FullName, $item.Length)
Write-Host ("SHA256 {0}" -f (Get-FileHash $sys -Algorithm SHA256).Hash)
