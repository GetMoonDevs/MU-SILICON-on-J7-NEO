[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$MuRoot
)

$ErrorActionPreference = 'Stop'
$overlay = $PSScriptRoot
$mu = (Resolve-Path $MuRoot).Path

$required = @(
    (Join-Path $mu 'build_uefi.py'),
    (Join-Path $mu 'Platforms\Samsung\gtaxlltePkg'),
    (Join-Path $mu 'Silicium-ACPI\Silicon\Samsung\S5E7870\DSDT.aml')
)
foreach ($path in $required) {
    if (-not (Test-Path -LiteralPath $path)) {
        throw "This is not an initialized Mu-Silicium checkout; missing: $path"
    }
}

$copies = @(
    @('Platforms\Samsung\j6ltePkg', 'Platforms\Samsung\j6ltePkg'),
    @('Resources\Configs\j6lte.toml', 'Resources\Configs\j6lte.toml'),
    @('Silicium-ACPI\Platforms\Samsung\j6lte', 'Silicium-ACPI\Platforms\Samsung\j6lte')
)

foreach ($copy in $copies) {
    $source = Join-Path $overlay $copy[0]
    $destination = Join-Path $mu $copy[1]
    if (Test-Path -LiteralPath $destination) {
        Remove-Item -LiteralPath $destination -Recurse -Force
    }
    New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
    Copy-Item -LiteralPath $source -Destination $destination -Recurse -Force
}

Write-Host "Applied j6lte platform overlay to: $mu"
Write-Host 'Build with: python build_uefi.py -d j6lte -r RELEASE -c'
