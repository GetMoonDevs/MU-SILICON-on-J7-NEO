# Driver design notes

## Why ZT7548 and mode 0

The mainline j6lte device tree uses the broad compatible string
`zinitix,bt532`. Samsung's downstream j6lte data is more specific:

- `zinitix,chip_name = "ZT7548"`
- firmware `tsp_zinitix/zt7548_j6.fw`
- chip code `0xE548`
- `TOUCH_POINT_MODE = 0`

Mode 0 returns a 34-byte frame:

```text
u16 status
u8  finger_count
u8  timestamp
5 * {
    u16 x
    u16 y
    u8  width
    u8  sub_status
}
```

The generic mode-2 layout is 44 bytes because every point has two additional
bytes. Reading the wrong size can consume unrelated controller state and makes
the report parser unreliable, so this driver explicitly programs mode 0.

## Initialization

The startup sequence is based on the controller protocol used by both Linux
drivers:

1. Enable S2MPU05 LDO34 at 3.3 V, then wait 15 ms.
2. Write `1` to `0xC000` (vendor commands).
3. Read chip code from `0xCC00`.
4. Send `0xC004` (vendor interrupt clear).
5. Write `1` to `0xC002` (NVM init), wait 2 ms.
6. Write `1` to `0xC001` (program start), wait 40 ms.
7. Soft-reset with command `0x0000`.
8. Disable controller interrupts, select point mode 0, select cover-open mode,
   clear optional mode, and enable point-count/down/move/up events.
9. Clear ten pending controller interrupts.

The driver never writes flash registers.

## I2C transaction shape

ZT7548 register reads require two independent I2C requests: a two-byte
little-endian register-pointer write followed by a read. A combined transfer
with a repeated start is known not to work on this family. `SpbWriteRead`
(the historical internal API name) holds one wait lock across both native
S3C2440-controller operations so another operation cannot interleave between
them. It also preserves Samsung's 50 microsecond register-latch delay before
the read and 10 microsecond post-transaction delay.

## Mu-Silicium bootstrap transport

Mu-Silicium's current S5E7870 ACPI has no SPB or GPIO controller nodes, and no
public Windows driver owns the legacy controller at `0x13890000`. Version 1.1
therefore uses a j6lte-only bootstrap transport:

1. ACPI assigns the fixed MMIO windows when a complete j6lte table is present;
   otherwise WinPE creates `ROOT\J6ZT7548` and the board-specific fallback maps
   the same documented physical addresses.
2. The driver enables the MIF/PERI clock gates and selects GPC2 function 2.
3. It uses the S3C2440-compatible controller in polling mode for address `0x20`.
4. It enables PMIC LDO34 by writing register `0x50` through HSI2C0.
5. A passive KMDF timer samples GPA0-6 and reads a point frame only while the
   active-low line is asserted.

This avoids unbounded blind reads and does not claim a GIC interrupt. It is a
bring-up design, not a substitute for reusable SpbCx/GpioClx controller drivers.
The root fallback deliberately avoids changing the working UEFI memory map.

## Contact lifetime

The Zinitix slot number is used directly as the Windows Contact ID. Each frame
is converted into:

1. every currently active contact; then
2. every slot that was active in the previous frame but is absent now, with
   Tip Switch clear and its last coordinate.

That explicit lift record satisfies the Windows touchscreen contact-lifetime
rules. The following frame omits the released contact.

## Power ownership

`MsHidKmdf` owns HID power policy. This driver is installed as its lower KMDF
filter and handles prepare/release hardware plus D0 entry/exit. During D0
preparation the bootstrap transport enables LDO34; the rail is deliberately
left enabled on D0 exit while the controller receives its sleep command.
