#include "driver.h"

#define HID_VENDOR_ID_SAMSUNG 0x04E8
#define HID_PRODUCT_ID_ZT7548 0x7548
#define HID_VERSION_DEFAULT   0x0100
#define HID_INDEXED_STRING_ID 1

#define J6_HID_CONTACT_COLLECTION \
    0x09, 0x22,             /* Usage (Finger) */ \
    0xA1, 0x02,             /* Collection (Logical) */ \
    0x09, 0x42,             /*   Usage (Tip Switch) */ \
    0x15, 0x00,             /*   Logical Minimum (0) */ \
    0x25, 0x01,             /*   Logical Maximum (1) */ \
    0x35, 0x00,             /*   Physical Minimum (0) */ \
    0x45, 0x01,             /*   Physical Maximum (1) */ \
    0x55, 0x00,             /*   Unit Exponent (0) */ \
    0x65, 0x00,             /*   Unit (None) */ \
    0x75, 0x01,             /*   Report Size (1) */ \
    0x95, 0x01,             /*   Report Count (1) */ \
    0x81, 0x02,             /*   Input (Data,Var,Abs) */ \
    0x09, 0x47,             /*   Usage (Confidence) */ \
    0x81, 0x02,             /*   Input (Data,Var,Abs) */ \
    0x95, 0x06,             /*   Report Count (6) */ \
    0x81, 0x03,             /*   Input (Const,Var,Abs) */ \
    0x75, 0x08,             /*   Report Size (8) */ \
    0x95, 0x01,             /*   Report Count (1) */ \
    0x09, 0x51,             /*   Usage (Contact Identifier) */ \
    0x25, 0x04,             /*   Logical Maximum (4) */ \
    0x45, 0x00,             /*   Physical Maximum (0) */ \
    0x81, 0x02,             /*   Input (Data,Var,Abs) */ \
    0x05, 0x01,             /*   Usage Page (Generic Desktop) */ \
    0x09, 0x30,             /*   Usage (X) */ \
    0x26, 0xCF, 0x02,       /*   Logical Maximum (719) */ \
    0x35, 0x00,             /*   Physical Minimum (0) */ \
    0x46, 0xF5, 0x00,       /*   Physical Maximum (2.45 in) */ \
    0x55, 0x0E,             /*   Unit Exponent (-2) */ \
    0x65, 0x13,             /*   Unit (Inch, English Linear) */ \
    0x75, 0x10,             /*   Report Size (16) */ \
    0x95, 0x01,             /*   Report Count (1) */ \
    0x81, 0x02,             /*   Input (Data,Var,Abs) */ \
    0x09, 0x31,             /*   Usage (Y) */ \
    0x26, 0xC7, 0x05,       /*   Logical Maximum (1479) */ \
    0x46, 0xF8, 0x01,       /*   Physical Maximum (5.04 in) */ \
    0x81, 0x02,             /*   Input (Data,Var,Abs) */ \
    0xC0                    /* End Collection */

static const UCHAR J6ReportDescriptor[] = {
    0x05, 0x0D,                         // Usage Page (Digitizers)
    0x09, 0x04,                         // Usage (Touch Screen)
    0xA1, 0x01,                         // Collection (Application)
    0x85, J6_TOUCH_REPORT_ID,           //   Report ID (Touch)

    J6_HID_CONTACT_COLLECTION,
    J6_HID_CONTACT_COLLECTION,
    J6_HID_CONTACT_COLLECTION,
    J6_HID_CONTACT_COLLECTION,
    J6_HID_CONTACT_COLLECTION,

    0x05, 0x0D,                         //   Usage Page (Digitizers)
    0x15, 0x00,                         //   Logical Minimum (0)
    0x25, J6_MAX_CONTACTS,              //   Logical Maximum (5)
    0x35, 0x00,                         //   Physical Minimum (0)
    0x45, 0x00,                         //   Physical Maximum (0)
    0x55, 0x00,                         //   Unit Exponent (0)
    0x65, 0x00,                         //   Unit (None)
    0x75, 0x08,                         //   Report Size (8)
    0x95, 0x01,                         //   Report Count (1)
    0x09, 0x54,                         //   Usage (Contact Count)
    0x81, 0x02,                         //   Input (Data,Var,Abs)

    0x85, J6_MAX_COUNT_REPORT_ID,       //   Report ID (Maximum Count)
    0x09, 0x55,                         //   Usage (Contact Count Maximum)
    0x25, J6_MAX_CONTACTS,              //   Logical Maximum (5)
    0xB1, 0x02,                         //   Feature (Data,Var,Abs)
    0xC0                                // End Collection
};

static const HID_DESCRIPTOR J6HidDescriptor = {
    (UCHAR)sizeof(HID_DESCRIPTOR),
    HID_HID_DESCRIPTOR_TYPE,
    0x0111,
    0,
    1,
    {
        {
            HID_REPORT_DESCRIPTOR_TYPE,
            (USHORT)sizeof(J6ReportDescriptor)
        }
    }
};

static const WCHAR J6ManufacturerString[] = L"Zinitix";
static const WCHAR J6ProductString[] = L"ZT7548 Touchscreen (Samsung j6lte)";
static const WCHAR J6SerialString[] = L"j6lte-i2c6-20";

static
NTSTATUS
HidCompleteInputRequest(
    _In_ WDFREQUEST Request,
    _In_ const J6_TOUCH_INPUT_REPORT* Report
    )
{
    NTSTATUS status;

    status = HidCopyToRequest(Request, Report, sizeof(*Report));
    WdfRequestComplete(Request, status);
    return status;
}

static
NTSTATUS
HidGetTransferPacket(
    _In_ WDFREQUEST Request,
    _In_ BOOLEAN ReadFromDevice,
    _Out_ HID_XFER_PACKET* Packet
    )
{
    WDF_REQUEST_PARAMETERS parameters;
    PIRP irp;
    size_t packetLength;

    WDF_REQUEST_PARAMETERS_INIT(&parameters);
    WdfRequestGetParameters(Request, &parameters);

    packetLength = ReadFromDevice
        ? parameters.Parameters.DeviceIoControl.OutputBufferLength
        : parameters.Parameters.DeviceIoControl.InputBufferLength;
    if (packetLength < sizeof(HID_XFER_PACKET)) {
        return STATUS_BUFFER_TOO_SMALL;
    }

    irp = WdfRequestWdmGetIrp(Request);
    if (irp == NULL || irp->UserBuffer == NULL) {
        return STATUS_INVALID_USER_BUFFER;
    }

    RtlCopyMemory(Packet, irp->UserBuffer, sizeof(*Packet));
    if (Packet->reportBuffer == NULL) {
        return STATUS_INVALID_USER_BUFFER;
    }

    return STATUS_SUCCESS;
}

VOID
HidInitializeState(
    _Inout_ PDEVICE_CONTEXT Context
    )
{
    ULONG index;

    Context->ReportHead = 0;
    Context->ReportTail = 0;
    Context->ReportCount = 0;
    RtlZeroMemory(&Context->LastReport, sizeof(Context->LastReport));
    Context->LastReport.ReportId = J6_TOUCH_REPORT_ID;

    for (index = 0; index < J6_MAX_CONTACTS; ++index) {
        Context->LastReport.Contacts[index].ContactId = (UCHAR)index;
    }
}

VOID
HidFlushReports(
    _Inout_ PDEVICE_CONTEXT Context
    )
{
    NTSTATUS status;

    status = WdfWaitLockAcquire(Context->ReportLock, NULL);
    if (!NT_SUCCESS(status)) {
        return;
    }

    Context->ReportHead = 0;
    Context->ReportTail = 0;
    Context->ReportCount = 0;
    RtlZeroMemory(&Context->LastReport, sizeof(Context->LastReport));
    Context->LastReport.ReportId = J6_TOUCH_REPORT_ID;

    WdfWaitLockRelease(Context->ReportLock);
}

NTSTATUS
HidCopyToRequest(
    _In_ WDFREQUEST Request,
    _In_reads_bytes_(Length) const VOID* Source,
    _In_ size_t Length
    )
{
    WDFMEMORY outputMemory;
    size_t outputLength;
    NTSTATUS status;

    status = WdfRequestRetrieveOutputMemory(Request, &outputMemory);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    (VOID)WdfMemoryGetBuffer(outputMemory, &outputLength);
    if (outputLength < Length) {
        return STATUS_BUFFER_TOO_SMALL;
    }

    status = WdfMemoryCopyFromBuffer(outputMemory, 0, (PVOID)Source, Length);
    if (NT_SUCCESS(status)) {
        WdfRequestSetInformation(Request, Length);
    }

    return status;
}

NTSTATUS
HidQueueInputReport(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ const J6_TOUCH_INPUT_REPORT* Report
    )
{
    WDFREQUEST request = NULL;
    NTSTATUS lockStatus;
    NTSTATUS status;

    lockStatus = WdfWaitLockAcquire(Context->ReportLock, NULL);
    if (!NT_SUCCESS(lockStatus)) {
        return lockStatus;
    }

    Context->LastReport = *Report;

    status = WdfIoQueueRetrieveNextRequest(Context->ReadQueue, &request);
    if (!NT_SUCCESS(status)) {
        if (status != STATUS_NO_MORE_ENTRIES) {
            WdfWaitLockRelease(Context->ReportLock);
            return status;
        }

        if (Context->ReportCount == J6_REPORT_QUEUE_DEPTH) {
            // Keep the newest state if HIDClass temporarily stops posting
            // reads. Dropping the oldest sample bounds nonpaged memory use.
            Context->ReportHead =
                (Context->ReportHead + 1) % J6_REPORT_QUEUE_DEPTH;
            --Context->ReportCount;
            J6_TRACE_ERROR("J6ZT7548: HID report ring full; dropped oldest frame\n");
        }

        Context->ReportQueue[Context->ReportTail] = *Report;
        Context->ReportTail =
            (Context->ReportTail + 1) % J6_REPORT_QUEUE_DEPTH;
        ++Context->ReportCount;
        WdfWaitLockRelease(Context->ReportLock);
        return STATUS_SUCCESS;
    }

    WdfWaitLockRelease(Context->ReportLock);
    return HidCompleteInputRequest(request, Report);
}

BOOLEAN
HidInputReportChanged(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ const J6_TOUCH_INPUT_REPORT* Report
    )
{
    BOOLEAN changed;
    NTSTATUS status;

    status = WdfWaitLockAcquire(Context->ReportLock, NULL);
    if (!NT_SUCCESS(status)) {
        // Do not suppress a hardware report merely because comparison failed.
        return TRUE;
    }

    changed = (RtlCompareMemory(
        &Context->LastReport,
        Report,
        sizeof(*Report)) != sizeof(*Report));

    WdfWaitLockRelease(Context->ReportLock);
    return changed;
}

NTSTATUS
HidReadReport(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ WDFREQUEST Request,
    _Out_ BOOLEAN* Pending
    )
{
    J6_TOUCH_INPUT_REPORT report;
    BOOLEAN haveReport = FALSE;
    NTSTATUS status;

    *Pending = FALSE;

    status = WdfWaitLockAcquire(Context->ReportLock, NULL);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    if (Context->ReportCount != 0) {
        report = Context->ReportQueue[Context->ReportHead];
        Context->ReportHead =
            (Context->ReportHead + 1) % J6_REPORT_QUEUE_DEPTH;
        --Context->ReportCount;
        haveReport = TRUE;
        status = STATUS_SUCCESS;
    } else {
        status = WdfRequestForwardToIoQueue(Request, Context->ReadQueue);
        if (NT_SUCCESS(status)) {
            *Pending = TRUE;
        }
    }

    WdfWaitLockRelease(Context->ReportLock);

    if (haveReport) {
        status = HidCopyToRequest(Request, &report, sizeof(report));
    }

    return status;
}

NTSTATUS
HidGetDeviceDescriptor(
    _In_ WDFREQUEST Request
    )
{
    return HidCopyToRequest(Request, &J6HidDescriptor, sizeof(J6HidDescriptor));
}

NTSTATUS
HidGetReportDescriptor(
    _In_ WDFREQUEST Request
    )
{
    return HidCopyToRequest(Request, J6ReportDescriptor, sizeof(J6ReportDescriptor));
}

NTSTATUS
HidGetDeviceAttributes(
    _In_ PDEVICE_CONTEXT Context,
    _In_ WDFREQUEST Request
    )
{
    HID_DEVICE_ATTRIBUTES attributes;

    RtlZeroMemory(&attributes, sizeof(attributes));
    attributes.Size = sizeof(attributes);
    attributes.VendorID = HID_VENDOR_ID_SAMSUNG;
    attributes.ProductID = HID_PRODUCT_ID_ZT7548;
    attributes.VersionNumber = Context->FirmwareVersion != 0
        ? Context->FirmwareVersion
        : HID_VERSION_DEFAULT;

    return HidCopyToRequest(Request, &attributes, sizeof(attributes));
}

NTSTATUS
HidGetString(
    _In_ WDFREQUEST Request,
    _In_ BOOLEAN Indexed
    )
{
    WDF_REQUEST_PARAMETERS parameters;
    ULONG inputValue;
    ULONG stringId;
    const WCHAR* string;
    size_t stringLength;

    WDF_REQUEST_PARAMETERS_INIT(&parameters);
    WdfRequestGetParameters(Request, &parameters);
    inputValue = PtrToUlong(
        parameters.Parameters.DeviceIoControl.Type3InputBuffer);
    stringId = inputValue & 0xFFFF;

    if (Indexed) {
        if (stringId != HID_INDEXED_STRING_ID) {
            return STATUS_INVALID_PARAMETER;
        }
        string = J6ProductString;
        stringLength = sizeof(J6ProductString);
    } else {
        switch (stringId) {
        case HID_STRING_ID_IMANUFACTURER:
            string = J6ManufacturerString;
            stringLength = sizeof(J6ManufacturerString);
            break;
        case HID_STRING_ID_IPRODUCT:
            string = J6ProductString;
            stringLength = sizeof(J6ProductString);
            break;
        case HID_STRING_ID_ISERIALNUMBER:
            string = J6SerialString;
            stringLength = sizeof(J6SerialString);
            break;
        default:
            return STATUS_INVALID_PARAMETER;
        }
    }

    return HidCopyToRequest(Request, string, stringLength);
}

NTSTATUS
HidGetFeature(
    _In_ WDFREQUEST Request
    )
{
    HID_XFER_PACKET packet;
    J6_MAX_COUNT_FEATURE_REPORT report;
    NTSTATUS status;

    status = HidGetTransferPacket(Request, TRUE, &packet);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    if (packet.reportId != J6_MAX_COUNT_REPORT_ID) {
        return STATUS_INVALID_PARAMETER;
    }
    if (packet.reportBufferLen < sizeof(report)) {
        return STATUS_BUFFER_TOO_SMALL;
    }

    report.ReportId = J6_MAX_COUNT_REPORT_ID;
    report.MaximumContactCount = J6_MAX_CONTACTS;
    RtlCopyMemory(packet.reportBuffer, &report, sizeof(report));
    WdfRequestSetInformation(Request, sizeof(report));
    return STATUS_SUCCESS;
}

NTSTATUS
HidGetInputReport(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ WDFREQUEST Request
    )
{
    HID_XFER_PACKET packet;
    J6_TOUCH_INPUT_REPORT report;
    NTSTATUS status;

    status = HidGetTransferPacket(Request, TRUE, &packet);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    if (packet.reportId != J6_TOUCH_REPORT_ID) {
        return STATUS_INVALID_PARAMETER;
    }
    if (packet.reportBufferLen < sizeof(report)) {
        return STATUS_BUFFER_TOO_SMALL;
    }

    status = WdfWaitLockAcquire(Context->ReportLock, NULL);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    report = Context->LastReport;
    WdfWaitLockRelease(Context->ReportLock);

    RtlCopyMemory(packet.reportBuffer, &report, sizeof(report));
    WdfRequestSetInformation(Request, sizeof(report));
    return STATUS_SUCCESS;
}

VOID
J6EvtIoInternalDeviceControl(
    _In_ WDFQUEUE Queue,
    _In_ WDFREQUEST Request,
    _In_ size_t OutputBufferLength,
    _In_ size_t InputBufferLength,
    _In_ ULONG IoControlCode
    )
{
    PDEVICE_CONTEXT context;
    WDFDEVICE device;
    BOOLEAN pending = FALSE;
    NTSTATUS status;

    UNREFERENCED_PARAMETER(OutputBufferLength);
    UNREFERENCED_PARAMETER(InputBufferLength);

    device = WdfIoQueueGetDevice(Queue);
    context = DeviceGetContext(device);

    switch (IoControlCode) {
    case IOCTL_HID_GET_DEVICE_DESCRIPTOR:
        status = HidGetDeviceDescriptor(Request);
        break;

    case IOCTL_HID_GET_REPORT_DESCRIPTOR:
        status = HidGetReportDescriptor(Request);
        break;

    case IOCTL_HID_GET_DEVICE_ATTRIBUTES:
        status = HidGetDeviceAttributes(context, Request);
        break;

    case IOCTL_HID_GET_STRING:
        status = HidGetString(Request, FALSE);
        break;

    case IOCTL_HID_GET_INDEXED_STRING:
        status = HidGetString(Request, TRUE);
        break;

    case IOCTL_HID_READ_REPORT:
        status = HidReadReport(context, Request, &pending);
        break;

    case IOCTL_HID_GET_FEATURE:
        status = HidGetFeature(Request);
        break;

    case IOCTL_HID_GET_INPUT_REPORT:
        status = HidGetInputReport(context, Request);
        break;

    case IOCTL_HID_ACTIVATE_DEVICE:
    case IOCTL_HID_DEACTIVATE_DEVICE:
        status = STATUS_SUCCESS;
        break;

    case IOCTL_HID_SEND_IDLE_NOTIFICATION_REQUEST:
    case IOCTL_HID_SET_FEATURE:
    case IOCTL_HID_WRITE_REPORT:
    case IOCTL_HID_SET_OUTPUT_REPORT:
    default:
        status = STATUS_NOT_SUPPORTED;
        break;
    }

    if (!pending) {
        WdfRequestComplete(Request, status);
    }
}
