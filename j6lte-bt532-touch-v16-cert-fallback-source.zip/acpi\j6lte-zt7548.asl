// ACPI SSDT for the Samsung Galaxy J6 (j6lte) bootstrap touchscreen driver.
//
// Mu-Silicium's current S5E7870 DSDT exposes no Windows I2C/GPIO controller
// devices.  Until native SpbCx/GpioClx controller drivers exist, the j6lte
// touch package owns these fixed MMIO ranges and polls GPA0-6 directly.

DefinitionBlock ("", "SSDT", 2, "J6WOA", "ZT7548", 1)
{
    Scope (\_SB)
    {
        Device (TSP0)
        {
            Name (_HID, "ZTX7548")
            Name (_CID, "ZTX5320")
            Name (_UID, Zero)
            Name (_DDN, "Zinitix ZT7548 Touchscreen")

            Method (_CRS, 0, NotSerialized)
            {
                Name (RBUF, ResourceTemplate ()
                {
                    // ZT7548 bus, PERI clock, and GPC2 pinmux.
                    Memory32Fixed (ReadWrite, 0x13890000, 0x00000100)
                    Memory32Fixed (ReadWrite, 0x101F0000, 0x00001000)
                    Memory32Fixed (ReadWrite, 0x139C0000, 0x00001000)

                    // S2MPU05 bus, MIF clock, and GPM0 pinmux.  The driver
                    // enables LDO34 at 3.3 V before probing the ZT7548.
                    Memory32Fixed (ReadWrite, 0x10510000, 0x00002000)
                    Memory32Fixed (ReadWrite, 0x10460000, 0x00001000)
                    Memory32Fixed (ReadWrite, 0x10530000, 0x00001000)

                    // ALIVE pin controller containing active-low GPA0-6.
                    Memory32Fixed (ReadWrite, 0x139F0000, 0x00001000)
                })

                Return (RBUF)
            }

            Method (_STA, 0, NotSerialized)
            {
                Return (0x0F)
            }

        }
    }
}
