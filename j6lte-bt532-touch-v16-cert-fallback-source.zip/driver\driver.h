#pragma once

#include <ntddk.h>
#include <wdf.h>
#include <hidport.h>

#define RESHUB_USE_HELPER_ROUTINES
#include <reshub.h>

#define J6_POOL_TAG ((ULONG)'6JTZ')

#define J6_TOUCH_REPORT_ID  0x01
#define J6_MAX_COUNT_REPORT_ID 0x02
#define J6_MAX_CONTACTS 5
#define J6_REPORT_QUEUE_DEPTH 32

#define J6_LOGICAL_MAX_X 719
#define J6_LOGICAL_MAX_Y 1479

#define J6_TOUCH_FLAG_TIP        0x01
#define J6_TOUCH_FLAG_CONFIDENCE 0x02

#define J6_TRACE_ERROR(...) \
    DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, __VA_ARGS__)

#if DBG
#define J6_TRACE_INFO(...) \
    DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_INFO_LEVEL, __VA_ARGS__)
#else
#define J6_TRACE_INFO(...) ((void)0)
#endif

#pragma pack(push, 1)
typedef struct _J6_TOUCH_CONTACT {
    UCHAR Flags;
    UCHAR ContactId;
    USHORT X;
    USHORT Y;
} J6_TOUCH_CONTACT, *PJ6_TOUCH_CONTACT;

typedef struct _J6_TOUCH_INPUT_REPORT {
    UCHAR ReportId;
    J6_TOUCH_CONTACT Contacts[J6_MAX_CONTACTS];
    UCHAR ContactCount;
} J6_TOUCH_INPUT_REPORT, *PJ6_TOUCH_INPUT_REPORT;

typedef struct _J6_MAX_COUNT_FEATURE_REPORT {
    UCHAR ReportId;
    UCHAR MaximumContactCount;
} J6_MAX_COUNT_FEATURE_REPORT, *PJ6_MAX_COUNT_FEATURE_REPORT;
#pragma pack(pop)

C_ASSERT(sizeof(J6_TOUCH_CONTACT) == 6);
C_ASSERT(sizeof(J6_TOUCH_INPUT_REPORT) == 32);
C_ASSERT(sizeof(J6_MAX_COUNT_FEATURE_REPORT) == 2);

typedef struct _DEVICE_CONTEXT {
    WDFDEVICE Device;
    WDFQUEUE DefaultQueue;
    WDFQUEUE ReadQueue;
    WDFTIMER PollTimer;

    WDFWAITLOCK SpbLock;

    // Bootstrap transport for Mu-Silicium's S5E7870 firmware.  That firmware
    // currently exposes no Windows SPB or GPIO controller devices, so this
    // j6lte-only driver uses the board's fixed MMIO windows and polls the
    // touch interrupt pin. ACPI resources are preferred when present; the
    // WinPE root-enumerated fallback maps the same documented addresses.
    PUCHAR TouchI2cRegisters;
    ULONG TouchI2cRegistersLength;
    PUCHAR PeriClockRegisters;
    ULONG PeriClockRegistersLength;
    PUCHAR NfcGpioRegisters;
    ULONG NfcGpioRegistersLength;
    PUCHAR PmicI2cRegisters;
    ULONG PmicI2cRegistersLength;
    PUCHAR MifClockRegisters;
    ULONG MifClockRegistersLength;
    PUCHAR MifGpioRegisters;
    ULONG MifGpioRegistersLength;
    PUCHAR AliveGpioRegisters;
    ULONG AliveGpioRegistersLength;
    BOOLEAN HardwarePrepared;

    WDFWAITLOCK ReportLock;
    J6_TOUCH_INPUT_REPORT ReportQueue[J6_REPORT_QUEUE_DEPTH];
    J6_TOUCH_INPUT_REPORT LastReport;
    ULONG ReportHead;
    ULONG ReportTail;
    ULONG ReportCount;

    BOOLEAN ControllerReady;
    ULONG ActiveContactMask;
    USHORT LastX[J6_MAX_CONTACTS];
    USHORT LastY[J6_MAX_CONTACTS];

    USHORT ChipCode;
    USHORT ChipRevision;
    USHORT FirmwareVersion;
    USHORT FirmwareMinorVersion;
    USHORT RegisterDataVersion;
    ULONG ConsecutiveReadFailures;
    BOOLEAN InputReportSeen;
} DEVICE_CONTEXT, *PDEVICE_CONTEXT;

WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(DEVICE_CONTEXT, DeviceGetContext);

DRIVER_INITIALIZE DriverEntry;
EVT_WDF_DRIVER_DEVICE_ADD J6EvtDeviceAdd;
EVT_WDF_DEVICE_PREPARE_HARDWARE J6EvtDevicePrepareHardware;
EVT_WDF_DEVICE_RELEASE_HARDWARE J6EvtDeviceReleaseHardware;
EVT_WDF_DEVICE_D0_ENTRY J6EvtDeviceD0Entry;
EVT_WDF_DEVICE_D0_EXIT J6EvtDeviceD0Exit;
EVT_WDF_TIMER J6EvtPollTimer;
EVT_WDF_IO_QUEUE_IO_INTERNAL_DEVICE_CONTROL J6EvtIoInternalDeviceControl;

VOID
J6SetDiagnosticValue(
    _In_ PDEVICE_CONTEXT Context,
    _In_z_ PCWSTR Name,
    _In_ ULONG Value
    );

NTSTATUS
SpbTargetOpen(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ WDFCMRESLIST ResourcesTranslated
    );

VOID
SpbTargetClose(
    _Inout_ PDEVICE_CONTEXT Context
    );

BOOLEAN
SpbTouchInterruptAsserted(
    _In_ PDEVICE_CONTEXT Context
    );

NTSTATUS
SpbWrite(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_reads_bytes_(Length) const UCHAR* Buffer,
    _In_ ULONG Length
    );

NTSTATUS
SpbWriteRead(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_reads_bytes_(WriteLength) const UCHAR* WriteBuffer,
    _In_ ULONG WriteLength,
    _Out_writes_bytes_(ReadLength) UCHAR* ReadBuffer,
    _In_ ULONG ReadLength
    );

NTSTATUS
Bt532Start(
    _Inout_ PDEVICE_CONTEXT Context
    );

NTSTATUS
Bt532Stop(
    _Inout_ PDEVICE_CONTEXT Context
    );

NTSTATUS
Bt532ReadInputReport(
    _Inout_ PDEVICE_CONTEXT Context,
    _Out_ PJ6_TOUCH_INPUT_REPORT Report
    );

VOID
HidInitializeState(
    _Inout_ PDEVICE_CONTEXT Context
    );

VOID
HidFlushReports(
    _Inout_ PDEVICE_CONTEXT Context
    );

NTSTATUS
HidQueueInputReport(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ const J6_TOUCH_INPUT_REPORT* Report
    );

BOOLEAN
HidInputReportChanged(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ const J6_TOUCH_INPUT_REPORT* Report
    );

NTSTATUS
HidReadReport(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ WDFREQUEST Request,
    _Out_ BOOLEAN* Pending
    );

NTSTATUS
HidCopyToRequest(
    _In_ WDFREQUEST Request,
    _In_reads_bytes_(Length) const VOID* Source,
    _In_ size_t Length
    );

NTSTATUS
HidGetDeviceDescriptor(
    _In_ WDFREQUEST Request
    );

NTSTATUS
HidGetReportDescriptor(
    _In_ WDFREQUEST Request
    );

NTSTATUS
HidGetDeviceAttributes(
    _In_ PDEVICE_CONTEXT Context,
    _In_ WDFREQUEST Request
    );

NTSTATUS
HidGetString(
    _In_ WDFREQUEST Request,
    _In_ BOOLEAN Indexed
    );

NTSTATUS
HidGetFeature(
    _In_ WDFREQUEST Request
    );

NTSTATUS
HidGetInputReport(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ WDFREQUEST Request
    );
