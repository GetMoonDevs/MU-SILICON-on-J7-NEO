[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$WimPath,

    [Parameter(Mandatory)]
    [string]$MountDirectory,

    [string]$Configuration = 'Release'
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$package = Join-Path $root "build\ARM64\$Configuration\J6LteBt532Touch"
$helper = Join-Path $root "build\ARM64\$Configuration\J6TrustCert\J6TrustCert.exe"
$deviceHelper = Join-Path $root "build\ARM64\$Configuration\J6CreateDevice\J6CreateDevice.exe"
$diagHelper = Join-Path $root "build\ARM64\$Configuration\J6Diag\J6Diag.exe"
$diskProbe = Join-Path $root "build\ARM64\$Configuration\J6DiskProbe\J6DiskProbe.exe"
$certificate = Join-Path $package 'J6LteBt532Touch.cer'
$msHidKmdfInf = Join-Path $env:windir 'INF\MsHidKmdf.inf'
$dism = Join-Path ${env:ProgramFiles(x86)} 'Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\DISM\dism.exe'

foreach ($path in @($WimPath, $MountDirectory, $helper, $deviceHelper, $diagHelper, $diskProbe, $certificate, $msHidKmdfInf, $dism)) {
    if (-not (Test-Path -LiteralPath $path)) {
        throw "Required path not found: $path"
    }
}

$mountChildren = @(Get-ChildItem -LiteralPath $MountDirectory -Force -ErrorAction SilentlyContinue)
if ($mountChildren.Count -ne 0) {
    throw "Mount directory is not empty: $MountDirectory"
}

$mounted = $false
try {
    & $dism /English /Mount-Image "/ImageFile:$WimPath" /Index:1 "/MountDir:$MountDirectory" /Optimize
    if ($LASTEXITCODE -ne 0) { throw "DISM mount failed: $LASTEXITCODE" }
    $mounted = $true

    $target = Join-Path $MountDirectory 'Windows\System32\J6Touch'
    New-Item -ItemType Directory -Path $target -Force | Out-Null
    Copy-Item $helper (Join-Path $target 'J6TrustCert.exe') -Force
    Copy-Item $deviceHelper (Join-Path $target 'J6CreateDevice.exe') -Force
    Copy-Item $diagHelper (Join-Path $target 'J6Diag.exe') -Force
    Copy-Item $diskProbe (Join-Path $target 'J6DiskProbe.exe') -Force
    Copy-Item $certificate (Join-Path $target 'J6LteBt532Touch.cer') -Force
    Copy-Item $msHidKmdfInf (Join-Path $MountDirectory 'Windows\INF\MsHidKmdf.inf') -Force
    $driverTarget = Join-Path $target 'Driver'
    New-Item -ItemType Directory -Path $driverTarget -Force | Out-Null
    Copy-Item (Join-Path $package '*') $driverTarget -Force

    $startup = @(
        '@echo off',
        'set J6LOG=%SystemRoot%\Temp\J6TouchStartup.log',
        'set J6SUMMARY=%SystemRoot%\Temp\J6TouchSummary.txt',
        'set J6STORAGE=%SystemRoot%\Temp\J6StorageReport.txt',
        'set J6DISKPART=%SystemRoot%\Temp\J6DiskPart.txt',
        '"%SystemRoot%\System32\J6Touch\J6TrustCert.exe" "%SystemRoot%\System32\J6Touch\J6LteBt532Touch.cer" > "%J6LOG%" 2>&1',
        'wpeinit',
        '"%SystemRoot%\System32\J6Touch\J6TrustCert.exe" "%SystemRoot%\System32\J6Touch\J6LteBt532Touch.cer" >> "%J6LOG%" 2>&1',
        '"%SystemRoot%\System32\J6Touch\J6CreateDevice.exe" "%SystemRoot%\System32\J6Touch\Driver\J6LteBt532Touch.inf" >> "%J6LOG%" 2>&1',
        'pnputil.exe /scan-devices >> "%J6LOG%" 2>&1',
        'pnputil.exe /enum-devices /connected /deviceids >> "%J6LOG%" 2>&1',
        'pnputil.exe /enum-devices /problem >> "%J6LOG%" 2>&1',
        'reg.exe query HKLM\SYSTEM\CurrentControlSet\Services\J6LteBt532Touch /s >> "%J6LOG%" 2>&1',
        'reg.exe query HKLM\SYSTEM\CurrentControlSet\Services\mshidkmdf /s >> "%J6LOG%" 2>&1',
        'reg.exe query HKLM\SYSTEM\CurrentControlSet\Services\dwcmshc /s >> "%J6LOG%" 2>&1',
        'reg.exe query HKLM\SYSTEM\CurrentControlSet\Enum\ACPI /s /f EXNS000A >> "%J6LOG%" 2>&1',
        'reg.exe query HKLM\SYSTEM\CurrentControlSet\Enum\ACPI /s /f ZTX >> "%J6LOG%" 2>&1',
        'reg.exe query HKLM\SYSTEM\CurrentControlSet\Enum\ROOT /s /f J6ZT7548 >> "%J6LOG%" 2>&1',
        'type "%SystemRoot%\INF\setupapi.dev.log" >> "%J6LOG%" 2>&1',
        '"%SystemRoot%\System32\J6Touch\J6Diag.exe" > "%J6SUMMARY%" 2>&1',
        'echo list disk > "%J6DISKPART%"',
        'echo list volume >> "%J6DISKPART%"',
        'echo select disk 0 >> "%J6DISKPART%"',
        'echo detail disk >> "%J6DISKPART%"',
        'echo list partition >> "%J6DISKPART%"',
        'echo J6LTE STORAGE REPORT > "%J6STORAGE%"',
        'type "%J6SUMMARY%" >> "%J6STORAGE%"',
        'echo. >> "%J6STORAGE%"',
        '"%SystemRoot%\System32\J6Touch\J6DiskProbe.exe" >> "%J6STORAGE%" 2>&1',
        'echo. >> "%J6STORAGE%"',
        'echo === DISKPART === >> "%J6STORAGE%"',
        'diskpart.exe /s "%J6DISKPART%" >> "%J6STORAGE%" 2>&1',
        'echo. >> "%J6STORAGE%"',
        'echo === MOUNTVOL === >> "%J6STORAGE%"',
        'mountvol.exe >> "%J6STORAGE%" 2>&1',
        'type "%J6STORAGE%" >> "%J6LOG%"',
        'for %%D in (C D E F G H I J K L M N O P Q R S T U V W Y Z) do @if exist %%D:\ copy /y "%J6LOG%" "%%D:\J6TouchStartup.log" >nul 2>&1',
        'for %%D in (C D E F G H I J K L M N O P Q R S T U V W Y Z) do @if exist %%D:\ copy /y "%J6SUMMARY%" "%%D:\J6TouchSummary.txt" >nul 2>&1',
        'for %%D in (C D E F G H I J K L M N O P Q R S T U V W Y Z) do @if exist %%D:\ copy /y "%J6STORAGE%" "%%D:\J6StorageReport.txt" >nul 2>&1',
        'mode con: cols=90 lines=30',
        'cls',
        'echo ============================================================',
        'echo              J6LTE TOUCH DIAGNOSTICS',
        'echo ============================================================',
        'type "%J6SUMMARY%"',
        'echo.',
        'echo Photograph this screen if touch is still unavailable.',
        'echo Full log: X:\Windows\Temp\J6TouchStartup.log',
        'start "" "%SystemRoot%\System32\notepad.exe" "%J6STORAGE%"'
    )
    $startup | Set-Content (Join-Path $MountDirectory 'Windows\System32\startnet.cmd') -Encoding ASCII

    & $dism /English /Unmount-Image "/MountDir:$MountDirectory" /Commit
    if ($LASTEXITCODE -ne 0) { throw "DISM commit failed: $LASTEXITCODE" }
    $mounted = $false
} finally {
    if ($mounted) {
        & $dism /English /Unmount-Image "/MountDir:$MountDirectory" /Discard
    }
}

Write-Host 'Added automatic test-certificate trust, PnP rescan, and startup log.'
