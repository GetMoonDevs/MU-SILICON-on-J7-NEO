@echo off
rem ===========================================================================
rem  J6Touch - autorun hook, executed by
rem      X:\PEMaterial\Autoruns\Runner.bat  (phase BeforeShell)
rem
rem  Installs the eMMC + touch drivers, drops shortcuts on the PE desktop and
rem  opens the diagnostic report window.
rem ===========================================================================
setlocal EnableExtensions
set "ROOT=X:\J6Touch"
if not exist "%ROOT%\Install-J6Drivers.cmd" for %%I in ("%~dp0..\..\..\..\J6Touch") do set "ROOT=%%~fI"

if not exist "%ROOT%\Install-J6Drivers.cmd" (
    echo [J6Touch] payload not found at %ROOT% >>"%SystemRoot%\Temp\J6TouchStartup.log" 2>&1
    exit /b 1
)

>>"%SystemRoot%\Temp\J6TouchStartup.log" echo [J6Touch] autorun %DATE% %TIME% payload=%ROOT%

call "%ROOT%\Install-J6Drivers.cmd" --auto >>"%SystemRoot%\Temp\J6TouchStartup.log" 2>&1
set "RC=%ERRORLEVEL%"
>>"%SystemRoot%\Temp\J6TouchStartup.log" echo [J6Touch] install exit=%RC%

rem --- shortcuts for manual re-runs -----------------------------------------
if exist "%SystemRoot%\..\Users\Default\Desktop" (
    copy /y "%ROOT%\J6TouchDiag.cmd" "%SystemRoot%\..\Users\Default\Desktop\J6 Touch Diagnostics.cmd" >nul 2>&1
    copy /y "%ROOT%\Reinstall-J6Drivers.cmd" "%SystemRoot%\..\Users\Default\Desktop\J6 Reinstall Drivers.cmd" >nul 2>&1
)

rem --- show the report in its own console window ----------------------------
start "J6 Touch Diagnostics" %SystemRoot%\System32\cmd.exe /k %ROOT%\J6TouchDiag.cmd

exit /b %RC%
