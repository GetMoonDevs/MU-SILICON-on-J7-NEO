================================================================
 J6 TOUCH + eMMC DRIVER PAYLOAD  (Windows PE)
 Samsung Galaxy J6 / SM-J600G - Zinitix ZT7548 touchscreen
================================================================

This folder is injected into the WinPE image at X:\J6Touch and is
started automatically at boot by

    X:\PEMaterial\Autoruns\Startup\BeforeShell\10-J6Touch.cmd

What it does
------------
1. Trusts the WDK test certificate (J6LteBt532Touch.cer,
   thumbprint E610DF3B2EA58E2971549FA8ABE2E4DFFCCF7A7E) in
   LocalMachine\ROOT and attempts LocalMachine\TrustedPublisher. A locked
   publisher store is non-fatal when ROOT succeeds in test-signing mode.
2. Copies MsHidKmdf.inf into X:\Windows\INF - the touch INF
   includes it via Include=/Needs= and Windows 10 LTSC does not ship it.
   Microsoft introduced this include INF in build 22000. The payload uses
   that declarative INF with this PE's own build-19041 mshidkmdf.sys; it
   does not replace any Windows binary.
3. Installs dwcmshc.sys (Exynos 7870 eMMC, ACPI\EXNS000A).
4. Installs J6LteBt532Touch.sys and creates ROOT\J6ZT7548.

The boot store already has testsigning Yes and winpe Yes, so
test-signed drivers are allowed without any BCD change.

Reading the result
------------------
The diagnostic window shows the driver's own stage counters. The
collector gives you an eight-second countdown; tap the screen repeatedly
during it. The important line is:

    Stage          0x0000001E     <- 30 = first touch frame read OK
    Chip code      0x0000E548     <- panel answered correctly

Pointer behavior varies between customized WinPE shells, so lack of visible
pointer movement alone is not a driver verdict. Stage 30 is authoritative.

Failure values and their meaning:
    0x80000002-0x80000006   KMDF object / queue / timer failure
    0x8000000A              SpbTargetOpen failed
    0x80000014              Bt532Start failed
    0x8000001E              first input report failed
    no Parameters key       driver never started (install problem)

If the log shows
    UpdateDriverForPlugAndPlayDevices failed: 3758096921 (0xE0000219)
the include INF was not visible to SetupAPI (SPAPI_E_NO_ASSOCIATED_SERVICE).
MsHidKmdf.inf must exist in X:\Windows\INF; the installer copies it there
from this folder on every run.

Files
-----
Install-J6Drivers.cmd     installs both packages (safe to re-run)
J6TouchDiag.cmd           collects the report, copies it to every
                          readable volume as J6TouchDiag.txt
Reinstall-J6Drivers.cmd   desktop wrapper for the installer
Get-J6TouchReport.ps1     PowerShell report tool (this PE has no
                          powershell.exe - use it on installed
                          Windows instead)
J6LteBt532Touch\          touch package (inf/sys/cat/cer)
dwcmshc\                  eMMC package (inf/sys/cat/cer)
MsHidKmdf.inf             build-22000 HID KMDF service-declaration INF
                          used as a compatibility include on build 19041
tools\                    J6TrustCert, J6CreateDevice, J6Diag,
                          J6DiskProbe

Reports are written to
    X:\Windows\Temp\J6TouchInstall.log
    X:\Windows\Temp\J6TouchDiag.txt
    X:\Windows\Temp\J6SetupapiMatches.txt
and copied to <drive>:\J6TouchDiag.txt / J6TouchInstall.log /
J6Setupapi.log on every readable volume, so they can be read back
after rebooting into Windows.

Manual runs
-----------
  X:\J6Touch\Install-J6Drivers.cmd
  X:\J6Touch\J6TouchDiag.cmd --pause

Both scripts are also on the PE desktop.
