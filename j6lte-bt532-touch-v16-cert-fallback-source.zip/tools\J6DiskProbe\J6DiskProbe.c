#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winioctl.h>
#include <stdio.h>
#include <stdint.h>

#pragma pack(push, 1)
typedef struct _RAW_GPT_HEADER {
    BYTE Signature[8];
    DWORD Revision;
    DWORD HeaderSize;
    DWORD HeaderCrc32;
    DWORD Reserved;
    ULONGLONG CurrentLba;
    ULONGLONG BackupLba;
    ULONGLONG FirstUsableLba;
    ULONGLONG LastUsableLba;
    GUID DiskGuid;
    ULONGLONG PartitionEntryLba;
    DWORD NumberOfPartitionEntries;
    DWORD SizeOfPartitionEntry;
    DWORD PartitionArrayCrc32;
} RAW_GPT_HEADER;

typedef struct _RAW_GPT_ENTRY {
    GUID PartitionType;
    GUID PartitionId;
    ULONGLONG FirstLba;
    ULONGLONG LastLba;
    ULONGLONG Attributes;
    WCHAR Name[36];
} RAW_GPT_ENTRY;
#pragma pack(pop)

static
DWORD
CalculateCrc32(
    _In_reads_bytes_(Length) const BYTE* Data,
    _In_ size_t Length
    )
{
    DWORD crc = 0xFFFFFFFF;
    size_t index;

    for (index = 0; index < Length; ++index) {
        DWORD bit;

        crc ^= Data[index];
        for (bit = 0; bit < 8; ++bit) {
            crc = (crc >> 1) ^ ((crc & 1) ? 0xEDB88320 : 0);
        }
    }
    return ~crc;
}

static
BOOL
ReadAtOffset(
    _In_ HANDLE Disk,
    _In_ ULONGLONG Offset,
    _Out_writes_bytes_(Length) BYTE* Buffer,
    _In_ DWORD Length
    )
{
    LARGE_INTEGER position;
    DWORD bytesRead = 0;

    position.QuadPart = (LONGLONG)Offset;
    if (!SetFilePointerEx(Disk, position, NULL, FILE_BEGIN)) {
        return FALSE;
    }
    return ReadFile(Disk, Buffer, Length, &bytesRead, NULL) && bytesRead == Length;
}

static
BOOL
GuidIsZero(
    _In_ const GUID* Value
    )
{
    static const GUID ZeroGuid = { 0 };

    return memcmp(Value, &ZeroGuid, sizeof(*Value)) == 0;
}

static
const WCHAR*
PartitionStyleName(
    _In_ PARTITION_STYLE Style
    )
{
    switch (Style) {
    case PARTITION_STYLE_MBR:
        return L"MBR";
    case PARTITION_STYLE_GPT:
        return L"GPT";
    case PARTITION_STYLE_RAW:
        return L"RAW";
    default:
        return L"unknown";
    }
}

int
wmain(void)
{
    HANDLE disk;
    BYTE descriptorBuffer[1024];
    STORAGE_PROPERTY_QUERY query;
    STORAGE_HOTPLUG_INFO hotplugInfo;
    BYTE geometryBuffer[4096];
    BYTE layoutBuffer[65536];
    DWORD bytesReturned = 0;
    DWORD bytesPerSector = 512;
    ULONGLONG diskBytes = 0;
    BYTE* sector = NULL;
    RAW_GPT_HEADER header;
    DWORD storedHeaderCrc;
    DWORD calculatedHeaderCrc = 0;
    BYTE* partitionArray = NULL;
    DWORD partitionArrayBytes = 0;
    DWORD calculatedArrayCrc = 0;
    DWORD nonEmptyEntries = 0;
    DWORD entryIndex;
    int returnCode = 1;

    wprintf(L"=== RAW EMMC/GPT PROBE (READ ONLY) ===\n");
    disk = CreateFileW(
        L"\\\\.\\PhysicalDrive0",
        GENERIC_READ,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL);
    if (disk == INVALID_HANDLE_VALUE) {
        wprintf(L"Open PhysicalDrive0 failed: %lu\n", GetLastError());
        return 1;
    }

    ZeroMemory(&query, sizeof(query));
    query.PropertyId = StorageDeviceProperty;
    query.QueryType = PropertyStandardQuery;
    if (DeviceIoControl(
            disk,
            IOCTL_STORAGE_QUERY_PROPERTY,
            &query,
            sizeof(query),
            descriptorBuffer,
            sizeof(descriptorBuffer),
            &bytesReturned,
            NULL)) {
        PSTORAGE_DEVICE_DESCRIPTOR descriptor =
            (PSTORAGE_DEVICE_DESCRIPTOR)descriptorBuffer;
        const char* product = "--";

        if (descriptor->ProductIdOffset != 0 &&
            descriptor->ProductIdOffset < bytesReturned) {
            product = (const char*)descriptorBuffer + descriptor->ProductIdOffset;
        }
        wprintf(
            L"Storage descriptor: bus=%u removable=%u product=%S\n",
            descriptor->BusType,
            descriptor->RemovableMedia,
            product);
    } else {
        wprintf(L"Storage descriptor failed: %lu\n", GetLastError());
    }

    ZeroMemory(&hotplugInfo, sizeof(hotplugInfo));
    hotplugInfo.Size = sizeof(hotplugInfo);
    if (DeviceIoControl(
            disk,
            IOCTL_STORAGE_GET_HOTPLUG_INFO,
            NULL,
            0,
            &hotplugInfo,
            sizeof(hotplugInfo),
            &bytesReturned,
            NULL)) {
        wprintf(
            L"Hotplug: device=%u media-removable=%u media-hotplug=%u write-cache=%u\n",
            hotplugInfo.DeviceHotplug,
            hotplugInfo.MediaRemovable,
            hotplugInfo.MediaHotplug,
            hotplugInfo.WriteCacheEnableOverride);
    } else {
        wprintf(L"Hotplug query failed: %lu\n", GetLastError());
    }

    if (DeviceIoControl(
            disk,
            IOCTL_DISK_GET_DRIVE_GEOMETRY_EX,
            NULL,
            0,
            geometryBuffer,
            sizeof(geometryBuffer),
            &bytesReturned,
            NULL)) {
        PDISK_GEOMETRY_EX geometry = (PDISK_GEOMETRY_EX)geometryBuffer;

        bytesPerSector = geometry->Geometry.BytesPerSector;
        diskBytes = (ULONGLONG)geometry->DiskSize.QuadPart;
        wprintf(
            L"Geometry: bytes=%I64u sectors=%I64u logical-sector=%lu\n",
            diskBytes,
            bytesPerSector == 0 ? 0 : diskBytes / bytesPerSector,
            bytesPerSector);
    } else {
        wprintf(L"Geometry query failed: %lu\n", GetLastError());
    }

    if (DeviceIoControl(
            disk,
            IOCTL_DISK_GET_DRIVE_LAYOUT_EX,
            NULL,
            0,
            layoutBuffer,
            sizeof(layoutBuffer),
            &bytesReturned,
            NULL)) {
        PDRIVE_LAYOUT_INFORMATION_EX layout =
            (PDRIVE_LAYOUT_INFORMATION_EX)layoutBuffer;

        wprintf(
            L"Windows layout parser: style=%ls (%u) partitions=%lu\n",
            PartitionStyleName(layout->PartitionStyle),
            layout->PartitionStyle,
            layout->PartitionCount);
    } else {
        wprintf(L"Windows layout parser failed: %lu\n", GetLastError());
    }

    if (bytesPerSector < 512 || bytesPerSector > 65536) {
        wprintf(L"Unsupported logical-sector size: %lu\n", bytesPerSector);
        goto Cleanup;
    }

    sector = (BYTE*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, bytesPerSector);
    if (sector == NULL) {
        wprintf(L"Sector buffer allocation failed\n");
        goto Cleanup;
    }

    if (!ReadAtOffset(disk, 0, sector, bytesPerSector)) {
        wprintf(L"Raw LBA0 read failed: %lu\n", GetLastError());
        goto Cleanup;
    }
    wprintf(
        L"LBA0: signature=%02X%02X first-type=0x%02X first-start=%lu first-size=%lu\n",
        sector[510],
        sector[511],
        sector[450],
        *(UNALIGNED DWORD*)&sector[454],
        *(UNALIGNED DWORD*)&sector[458]);

    ZeroMemory(sector, bytesPerSector);
    if (!ReadAtOffset(disk, bytesPerSector, sector, bytesPerSector)) {
        wprintf(L"Raw LBA1 read failed: %lu\n", GetLastError());
        goto Cleanup;
    }
    if (bytesPerSector < sizeof(header)) {
        wprintf(L"Logical sector is smaller than GPT header\n");
        goto Cleanup;
    }
    CopyMemory(&header, sector, sizeof(header));
    wprintf(
        L"LBA1: signature='%c%c%c%c%c%c%c%c' revision=0x%08lX header=%lu\n",
        header.Signature[0], header.Signature[1], header.Signature[2], header.Signature[3],
        header.Signature[4], header.Signature[5], header.Signature[6], header.Signature[7],
        header.Revision,
        header.HeaderSize);

    if (memcmp(header.Signature, "EFI PART", 8) != 0 ||
        header.HeaderSize < sizeof(RAW_GPT_HEADER) ||
        header.HeaderSize > bytesPerSector) {
        wprintf(L"Primary GPT header is not structurally valid\n");
        goto Cleanup;
    }

    storedHeaderCrc = header.HeaderCrc32;
    *(UNALIGNED DWORD*)(sector + FIELD_OFFSET(RAW_GPT_HEADER, HeaderCrc32)) = 0;
    calculatedHeaderCrc = CalculateCrc32(sector, header.HeaderSize);
    wprintf(
        L"GPT header CRC: stored=0x%08lX calculated=0x%08lX match=%ls\n",
        storedHeaderCrc,
        calculatedHeaderCrc,
        storedHeaderCrc == calculatedHeaderCrc ? L"yes" : L"NO");
    wprintf(
        L"GPT range: current=%I64u backup=%I64u usable=%I64u-%I64u entries=%lu x %lu at %I64u\n",
        header.CurrentLba,
        header.BackupLba,
        header.FirstUsableLba,
        header.LastUsableLba,
        header.NumberOfPartitionEntries,
        header.SizeOfPartitionEntry,
        header.PartitionEntryLba);

    if (header.NumberOfPartitionEntries == 0 ||
        header.NumberOfPartitionEntries > 4096 ||
        header.SizeOfPartitionEntry < sizeof(RAW_GPT_ENTRY) ||
        header.SizeOfPartitionEntry > 4096 ||
        header.NumberOfPartitionEntries >
            (1024 * 1024) / header.SizeOfPartitionEntry) {
        wprintf(L"GPT partition-array dimensions are unsafe\n");
        goto Cleanup;
    }

    partitionArrayBytes =
        header.NumberOfPartitionEntries * header.SizeOfPartitionEntry;
    partitionArray = (BYTE*)HeapAlloc(
        GetProcessHeap(),
        HEAP_ZERO_MEMORY,
        partitionArrayBytes);
    if (partitionArray == NULL) {
        wprintf(L"Partition-array allocation failed\n");
        goto Cleanup;
    }
    if (!ReadAtOffset(
            disk,
            header.PartitionEntryLba * bytesPerSector,
            partitionArray,
            partitionArrayBytes)) {
        wprintf(L"GPT partition-array read failed: %lu\n", GetLastError());
        goto Cleanup;
    }

    calculatedArrayCrc = CalculateCrc32(partitionArray, partitionArrayBytes);
    for (entryIndex = 0; entryIndex < header.NumberOfPartitionEntries; ++entryIndex) {
        const RAW_GPT_ENTRY* entry = (const RAW_GPT_ENTRY*)(
            partitionArray + ((size_t)entryIndex * header.SizeOfPartitionEntry));

        if (!GuidIsZero(&entry->PartitionType)) {
            ++nonEmptyEntries;
        }
        if (entryIndex == 24 || entryIndex == 25) {
            WCHAR name[37];

            CopyMemory(name, entry->Name, sizeof(entry->Name));
            name[36] = L'\0';
            wprintf(
                L"GPT entry %lu: used=%ls first=%I64u last=%I64u name='%ls'\n",
                entryIndex + 1,
                GuidIsZero(&entry->PartitionType) ? L"no" : L"yes",
                entry->FirstLba,
                entry->LastLba,
                name);
        }
    }
    wprintf(
        L"GPT array CRC: stored=0x%08lX calculated=0x%08lX match=%ls used=%lu\n",
        header.PartitionArrayCrc32,
        calculatedArrayCrc,
        header.PartitionArrayCrc32 == calculatedArrayCrc ? L"yes" : L"NO",
        nonEmptyEntries);

    returnCode = 0;

Cleanup:
    if (partitionArray != NULL) {
        HeapFree(GetProcessHeap(), 0, partitionArray);
    }
    if (sector != NULL) {
        HeapFree(GetProcessHeap(), 0, sector);
    }
    CloseHandle(disk);
    return returnCode;
}
