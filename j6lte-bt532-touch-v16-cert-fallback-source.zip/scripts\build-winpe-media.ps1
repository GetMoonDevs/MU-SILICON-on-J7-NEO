#requires -version 5.1
<#
.SYNOPSIS
    Builds the J6 touch + eMMC WinPE media zip from the untouched
    winpe_desktop_NODRIVERS.zip, without administrator rights.

.DESCRIPTION
    The source zip is expanded to a work directory, the driver payload is
    staged into X:\J6Touch, wimlib-imagex (user-mode WIM library) injects the
    payload plus the BeforeShell autorun into sources\boot.wim, and the result
    is repacked as a new zip.  The source zip is never modified.

    Everything that is injected comes from this repository plus the shipped
    driver packages, so the media can be rebuilt at any time:

        build\ARM64\Release\J6LteBt532Touch\   touch package (v20.11.14.1)
        <DriverSource>\dwcmshc\                 eMMC package
        %windir%\INF\MsHidKmdf.inf              build-22000 compatibility
                                                   include INF (declarations only)
        winpe\*.cmd, winpe\README.txt           payload scripts

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File build-winpe-media.ps1
#>
[CmdletBinding()]
param(
    [string]$SourceZip = 'C:\Users\alerk\Desktop\j6lte-win\media\original-w10\winpe_desktop_NODRIVERS.zip',
    [string]$OutputZip = 'C:\Users\alerk\Desktop\j6lte-win\media\original-w10\winpe_desktop_J6TOUCH.zip',
    [string]$WimlibImagex = 'C:\Users\alerk\AppData\Local\Temp\opencode\wimlib\wimlib-imagex.exe',
    [string]$DriverSource = 'C:\Users\alerk\Desktop\j6lte-win\drivers-release',
    [string]$MsHidKmdfInf = "$env:windir\INF\MsHidKmdf.inf",
    [string]$WorkRoot = 'C:\Users\alerk\AppData\Local\Temp\opencode\j6winpe-build',
    [string]$ReportTool,
    [switch]$SkipZip
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$payloadSource = Join-Path $root 'winpe'
$touchPackage = Join-Path $root 'build\ARM64\Release\J6LteBt532Touch'
$storagePackage = Join-Path $DriverSource 'dwcmshc'
$toolsDir = Join-Path $root 'build\ARM64\Release'

if (-not $ReportTool) {
    $ReportTool = Join-Path $DriverSource 'Get-J6TouchReport.ps1'
}

function Assert-Path([string]$Path, [string]$Description) {
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "$Description not found: $Path"
    }
}

Assert-Path $SourceZip 'Source WinPE zip'
Assert-Path $WimlibImagex 'wimlib-imagex.exe'
Assert-Path $touchPackage 'Touch driver package'
Assert-Path $storagePackage 'eMMC driver package'
Assert-Path $payloadSource 'Payload script folder'
Assert-Path $MsHidKmdfInf 'MsHidKmdf.inf'
foreach ($tool in 'J6TrustCert', 'J6CreateDevice', 'J6Diag', 'J6DiskProbe') {
    Assert-Path (Join-Path $toolsDir "$tool\$tool.exe") "Tool $tool"
}

# --- fresh work area ------------------------------------------------------
if (Test-Path -LiteralPath $WorkRoot) {
    Remove-Item -LiteralPath $WorkRoot -Recurse -Force
}
$media = Join-Path $WorkRoot 'media'
$payload = Join-Path $WorkRoot 'payload\J6Touch'
$autorun = Join-Path $WorkRoot 'payload\autorun'
New-Item -ItemType Directory -Path $media, $payload, $autorun -Force | Out-Null

Write-Host "Expanding $SourceZip"
Expand-Archive -LiteralPath $SourceZip -DestinationPath $media -Force

$wim = Join-Path $media 'sources\boot.wim'
Assert-Path $wim 'boot.wim'

# --- stage the payload ----------------------------------------------------
Write-Host 'Staging X:\J6Touch'
$touchTarget = Join-Path $payload 'J6LteBt532Touch'
$storageTarget = Join-Path $payload 'dwcmshc'
$toolTarget = Join-Path $payload 'tools'
New-Item -ItemType Directory -Path $touchTarget, $storageTarget, $toolTarget -Force | Out-Null

Copy-Item (Join-Path $touchPackage '*') $touchTarget -Force
Copy-Item (Join-Path $storagePackage '*') $storageTarget -Force
foreach ($tool in 'J6TrustCert', 'J6CreateDevice', 'J6Diag', 'J6DiskProbe') {
    Copy-Item (Join-Path $toolsDir "$tool\$tool.exe") (Join-Path $toolTarget "$tool.exe") -Force
}
Copy-Item $MsHidKmdfInf (Join-Path $payload 'MsHidKmdf.inf') -Force
Copy-Item $ReportTool (Join-Path $payload 'Get-J6TouchReport.ps1') -Force
Copy-Item (Join-Path $payloadSource '*.cmd') $payload -Force
Copy-Item (Join-Path $payloadSource 'README.txt') $payload -Force
Copy-Item (Join-Path $payloadSource '10-J6Touch.cmd') $autorun -Force

# --- inject into the WIM --------------------------------------------------
$commands = @(
    "add `"$payload`" `"\J6Touch`"",
    "add `"$(Join-Path $autorun '10-J6Touch.cmd')`" `"\PEMaterial\Autoruns\Startup\BeforeShell\10-J6Touch.cmd`"",
    "add `"$MsHidKmdfInf`" `"\Windows\INF\MsHidKmdf.inf`""
)

$commandFile = Join-Path $WorkRoot 'wimlib-commands.txt'
Set-Content -LiteralPath $commandFile -Value $commands -Encoding ASCII

Write-Host 'Injecting payload (this rewrites the 566 MiB WIM, several minutes)'
$updateStdout = Join-Path $WorkRoot 'wimlib-update.out.txt'
$updateStderr = Join-Path $WorkRoot 'wimlib-update.err.txt'
$updateArgs = @('update', ('"{0}"' -f $wim), '--check', '--threads=4')
$updateProcess = Start-Process -FilePath $WimlibImagex -ArgumentList $updateArgs `
    -RedirectStandardInput $commandFile -RedirectStandardOutput $updateStdout `
    -RedirectStandardError $updateStderr -NoNewWindow -Wait -PassThru
Get-Content -LiteralPath $updateStdout | ForEach-Object { Write-Host $_ }
Get-Content -LiteralPath $updateStderr | ForEach-Object { Write-Host $_ }
if ($updateProcess.ExitCode -ne 0) {
    throw "wimlib-imagex update failed: exit $($updateProcess.ExitCode)"
}

# --- verify ---------------------------------------------------------------
Write-Host 'Verifying WIM'
$info = & $WimlibImagex info $wim
if ($LASTEXITCODE -ne 0) { throw 'wimlib-imagex info failed' }
$info | Where-Object { $_ -match '^(Image Count|Boot Index|Compression|Architecture|Name|Flags)' } |
    ForEach-Object { Write-Host "  $_" }
if (-not ($info | Where-Object { $_ -match '^Image Count:\s+1$' })) {
    throw 'boot.wim no longer has exactly one image'
}

$payloadList = & $WimlibImagex dir $wim 1 --path='\J6Touch'
if ($LASTEXITCODE -ne 0) { throw 'payload folder missing from WIM' }
$autorunList = & $WimlibImagex dir $wim 1 --path='\PEMaterial\Autoruns\Startup\BeforeShell'
if ($LASTEXITCODE -ne 0) { throw 'autorun folder missing from WIM' }
if (-not ($autorunList -match '10-J6Touch\.cmd')) { throw 'autorun was not injected' }

$expected = @(
    'J6LteBt532Touch\J6LteBt532Touch.inf',
    'J6LteBt532Touch\J6LteBt532Touch.sys',
    'J6LteBt532Touch\J6LteBt532Touch.cat',
    'dwcmshc\dwcmshc.inf',
    'dwcmshc\dwcmshc.sys',
    'dwcmshc\dwcmshc.cat',
    'tools\J6TrustCert.exe',
    'tools\J6CreateDevice.exe',
    'tools\J6Diag.exe',
    'MsHidKmdf.inf',
    'Install-J6Drivers.cmd',
    'J6TouchDiag.cmd'
)
foreach ($item in $expected) {
    if (-not ($payloadList -match [regex]::Escape($item))) {
        throw "missing from WIM payload: $item"
    }
}

$infList = & $WimlibImagex dir $wim 1 --path='\Windows\INF'
if (-not ($infList -match 'MsHidKmdf\.inf')) { throw 'Windows\INF\MsHidKmdf.inf missing' }

Write-Host ("  payload entries: {0}" -f $payloadList.Count)

# --- repack ---------------------------------------------------------------
if ($SkipZip) {
    Write-Host "SkipZip set; media tree left in $media"
    return
}

if (Test-Path -LiteralPath $OutputZip) {
    Remove-Item -LiteralPath $OutputZip -Force
}
Add-Type -AssemblyName System.IO.Compression.FileSystem

# The source zip uses forward-slash entry names and explicit directory entries
# (.NET Framework's CreateFromDirectory would write backslashes instead), so
# rebuild the archive entry by entry and only substitute sources/boot.wim.
Write-Host "Packing $OutputZip"
$wimName = 'sources/boot.wim'
$sourceArchive = [IO.Compression.ZipFile]::OpenRead($SourceZip)
try {
    $outputStream = [IO.File]::Open($OutputZip, [IO.FileMode]::CreateNew, [IO.FileAccess]::ReadWrite)
    try {
        $outputArchive = New-Object IO.Compression.ZipArchive($outputStream, [IO.Compression.ZipArchiveMode]::Create)
        try {
            foreach ($entry in $sourceArchive.Entries) {
                $newEntry = $outputArchive.CreateEntry($entry.FullName, [IO.Compression.CompressionLevel]::Fastest)
                $newEntry.LastWriteTime = $entry.LastWriteTime
                if ([string]::IsNullOrEmpty($entry.Name)) {
                    continue   # directory entry
                }
                if ($entry.FullName -eq $wimName) {
                    $reader = [IO.File]::OpenRead($wim)
                } else {
                    $reader = $entry.Open()
                }
                try {
                    $writer = $newEntry.Open()
                    try { $reader.CopyTo($writer) } finally { $writer.Dispose() }
                } finally { $reader.Dispose() }
            }
        } finally { $outputArchive.Dispose() }
    } finally { $outputStream.Dispose() }
} finally { $sourceArchive.Dispose() }

$sourceHash = (Get-FileHash -LiteralPath $SourceZip -Algorithm SHA256).Hash
$outputHash = (Get-FileHash -LiteralPath $OutputZip -Algorithm SHA256).Hash
$outputSize = (Get-Item -LiteralPath $OutputZip).Length

Write-Host ''
Write-Host 'Source (untouched)'
Write-Host ("  {0}`n  SHA256 {1}" -f $SourceZip, $sourceHash)
Write-Host 'Output'
Write-Host ("  {0}`n  {1:N1} MiB`n  SHA256 {2}" -f $OutputZip, ($outputSize / 1MB), $outputHash)
Write-Host ("WIM SHA256 {0}" -f (Get-FileHash -LiteralPath $wim -Algorithm SHA256).Hash)

# wimlib writes harmless SACL warnings to stderr when this intentionally runs
# without elevation.  Force a successful process status after every explicit
# wimlib return code and artifact check above has passed.
exit 0
