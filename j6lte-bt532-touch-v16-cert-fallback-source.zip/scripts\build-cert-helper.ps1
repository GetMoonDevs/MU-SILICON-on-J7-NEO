$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$source = Join-Path $root 'tools\J6TrustCert\J6TrustCert.c'
$outputDirectory = Join-Path $root 'build\ARM64\Release\J6TrustCert'
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$installation = & $vswhere -latest -products * -property installationPath
$vcvars = Join-Path $installation 'VC\Auxiliary\Build\vcvarsall.bat'

if (-not (Test-Path $vcvars)) {
    throw 'Visual C++ ARM64 build environment was not found.'
}

New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
$output = Join-Path $outputDirectory 'J6TrustCert.exe'
$object = Join-Path $outputDirectory 'J6TrustCert.obj'
$command = "call `"$vcvars`" amd64_arm64 && cl.exe /nologo /W4 /WX /O2 /MT /DUNICODE /D_UNICODE `"$source`" /Fo:`"$object`" /Fe:`"$output`" /link /subsystem:console crypt32.lib"
& cmd.exe /d /s /c $command
if ($LASTEXITCODE -ne 0) {
    throw "J6TrustCert build failed with exit code $LASTEXITCODE."
}

Write-Host "ARM64 certificate helper: $output"
