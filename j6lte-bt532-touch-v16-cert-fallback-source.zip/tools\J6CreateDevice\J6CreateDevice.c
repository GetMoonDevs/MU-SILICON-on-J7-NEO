#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <setupapi.h>
#include <newdev.h>
#include <devguid.h>
#include <cfgmgr32.h>
#include <stdio.h>

static const WCHAR J6HardwareId[] = L"ROOT\\J6ZT7548\0";
static const WCHAR J6DefaultInstanceId[] = L"ROOT\\J6ZT7548\\0000";

int
wmain(
    int ArgumentCount,
    WCHAR** Arguments
    )
{
    HDEVINFO deviceInfoSet;
    SP_DEVINFO_DATA deviceInfo;
    WCHAR infPath[MAX_PATH];
    WCHAR instanceId[MAX_DEVICE_ID_LEN];
    BOOL rebootRequired;
    DWORD error;
    DEVINST deviceInstance;
    ULONG deviceStatus = 0;
    ULONG problemCode = 0;
    CONFIGRET configResult;
    BOOL deviceCreated = FALSE;

    if (ArgumentCount != 2) {
        wprintf(L"Usage: J6CreateDevice.exe J6LteBt532Touch.inf\n");
        return 2;
    }

    if (GetFullPathNameW(Arguments[1], ARRAYSIZE(infPath), infPath, NULL) == 0) {
        wprintf(L"GetFullPathName failed: %lu\n", GetLastError());
        return 3;
    }

    CopyMemory(instanceId, J6DefaultInstanceId, sizeof(J6DefaultInstanceId));
    configResult = CM_Locate_DevNodeW(
        &deviceInstance,
        instanceId,
        CM_LOCATE_DEVNODE_NORMAL);
    if (configResult == CR_SUCCESS) {
        wprintf(L"Using existing device instance: %ls\n", instanceId);
        goto InstallDriver;
    }

    deviceInfoSet = SetupDiCreateDeviceInfoList(&GUID_DEVCLASS_HIDCLASS, NULL);
    if (deviceInfoSet == INVALID_HANDLE_VALUE) {
        wprintf(L"SetupDiCreateDeviceInfoList failed: %lu\n", GetLastError());
        return 4;
    }

    ZeroMemory(&deviceInfo, sizeof(deviceInfo));
    deviceInfo.cbSize = sizeof(deviceInfo);
    if (!SetupDiCreateDeviceInfoW(
            deviceInfoSet,
            L"J6ZT7548",
            &GUID_DEVCLASS_HIDCLASS,
            L"Samsung Galaxy J6 Zinitix ZT7548 Touchscreen",
            NULL,
            DICD_GENERATE_ID,
            &deviceInfo)) {
        error = GetLastError();
        wprintf(L"SetupDiCreateDeviceInfo failed: %lu\n", error);
        SetupDiDestroyDeviceInfoList(deviceInfoSet);
        return 5;
    }

    if (!SetupDiSetDeviceRegistryPropertyW(
            deviceInfoSet,
            &deviceInfo,
            SPDRP_HARDWAREID,
            (const BYTE*)J6HardwareId,
            sizeof(J6HardwareId))) {
        error = GetLastError();
        wprintf(L"Setting ROOT\\J6ZT7548 hardware ID failed: %lu\n", error);
        SetupDiDestroyDeviceInfoList(deviceInfoSet);
        return 6;
    }

    if (!SetupDiCallClassInstaller(
            DIF_REGISTERDEVICE,
            deviceInfoSet,
            &deviceInfo)) {
        error = GetLastError();
        wprintf(L"Registering root device failed: %lu\n", error);
        SetupDiDestroyDeviceInfoList(deviceInfoSet);
        return 7;
    }

    if (!SetupDiGetDeviceInstanceIdW(
            deviceInfoSet,
            &deviceInfo,
            instanceId,
            ARRAYSIZE(instanceId),
            NULL)) {
        error = GetLastError();
        wprintf(L"Reading root device instance ID failed: %lu\n", error);
        SetupDiDestroyDeviceInfoList(deviceInfoSet);
        return 8;
    }
    SetupDiDestroyDeviceInfoList(deviceInfoSet);
    deviceCreated = TRUE;

    wprintf(L"Created device instance: %ls\n", instanceId);

InstallDriver:
    rebootRequired = FALSE;
    if (!UpdateDriverForPlugAndPlayDevicesW(
            NULL,
            L"ROOT\\J6ZT7548",
            infPath,
            INSTALLFLAG_FORCE | INSTALLFLAG_NONINTERACTIVE,
            &rebootRequired)) {
        error = GetLastError();
        wprintf(
            L"UpdateDriverForPlugAndPlayDevices failed: %lu (0x%08lX)\n",
            error,
            error);
        return 9;
    }

    wprintf(
        L"ROOT\\J6ZT7548 %ls and driver installed. Reboot required: %ls\n",
        deviceCreated ? L"created" : L"updated",
        rebootRequired ? L"yes" : L"no");

    configResult = CM_Locate_DevNodeW(
        &deviceInstance,
        instanceId,
        CM_LOCATE_DEVNODE_NORMAL);
    if (configResult == CR_SUCCESS) {
        configResult = CM_Get_DevNode_Status(
            &deviceStatus,
            &problemCode,
            deviceInstance,
            0);
    }
    if (configResult == CR_SUCCESS) {
        wprintf(
            L"PnP status: 0x%08lX, problem code: %lu (0x%08lX)\n",
            deviceStatus,
            problemCode,
            problemCode);
    } else {
        wprintf(L"CM_Get_DevNode_Status failed: CR 0x%08lX\n", configResult);
    }

    return rebootRequired ? 1 : 0;
}
