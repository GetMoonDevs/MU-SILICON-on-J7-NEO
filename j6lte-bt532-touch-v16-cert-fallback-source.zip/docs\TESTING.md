# Target test plan

Use a recoverable Windows-on-ARM installation and have a known-good way to
restore the boot volume before testing any new kernel driver.

## 1. Validate dependencies first

- Use the previously verified, resolution-modified gtaxllte Mu-Silicium build.
  Do **not** flash the failed experimental `j6ltePkg` image.
- Confirm the startup log says `ROOT\J6ZT7548 created and driver installed`.
- Confirm PnP shows hardware ID `ROOT\J6ZT7548`.
- Confirm Secure Boot is disabled and `{current}` reports `testsigning Yes`.

## 2. Enable diagnostics

Attach WinDbg over the transport available on the phone and enable kernel
prints for the IHV driver component. Messages are prefixed with `J6ZT7548`.

On successful startup, the driver prints a line containing:

```text
chip=0xE548 rev=... fw=... data=...
```

The customized WinPE runs certificate trust and a PnP rescan automatically.
It writes `J6TouchStartup.log` to `X:\Windows\Temp` and copies the log to the
root of every writable volume it finds, so diagnostics can be recovered even
when USB host/keyboard input is unavailable.

An `LDO34 enable transaction failed` message points to HSI2C0 clock, pinmux, or
PMIC access. Repeated ZT7548 power-sequence failures mean LDO34 is off, the
GPC2 I2C pinmux is wrong, or address `0x20` is not responding.

## 3. Stage and start

Use a test-signed package or a production-signed catalog. From elevated
PowerShell on the phone:

```powershell
pnputil /add-driver .\J6LteBt532Touch.inf /install
Get-PnpDevice -PresentOnly | Where-Object InstanceId -like 'ROOT\J6ZT7548*'
```

Expected Device Manager topology:

```text
Human Interface Devices
  Zinitix ZT7548 Touchscreen for Samsung Galaxy J6
HID-compliant touch screen
```

## 4. Functional checks

1. Single-finger down, drag, and lift across all four edges.
2. Two- through five-finger simultaneous contacts.
3. Lift contacts in a different order from their placement order.
4. Rapid taps to check that release frames are not lost.
5. Screen off/on and system sleep/resume.
6. At least 30 minutes of continuous interaction while monitoring for I2C
   errors, interrupt storms, or nonpaged-pool growth.

Coordinate (0,0) must map to the top-left in the display's native portrait
orientation. If axes are wrong, correct the platform/display orientation or add
an explicit transform after collecting raw-coordinate logs; do not guess.

## 5. Failure recovery

If the target boot-loops, remove the package offline or stop creating the root
device from `startnet.cmd`. Do not mark the service boot-start while it is
experimental; the supplied INF uses demand start.
