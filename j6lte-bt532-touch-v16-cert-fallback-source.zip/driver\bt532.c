#include "driver.h"

// ZT7548 uses the BT532-family register protocol.
#define BT532_SWRESET_CMD               0x0000
#define BT532_SLEEP_CMD                 0x0005
#define BT532_CLEAR_INT_STATUS_CMD      0x0003
#define BT532_TOUCH_MODE                0x0010
#define BT532_CHIP_REVISION             0x0011
#define BT532_FIRMWARE_VERSION          0x0012
#define BT532_DATA_VERSION              0x0013
#define BT532_MINOR_FIRMWARE_VERSION    0x0121
#define BT532_POINT_STATUS              0x0080
#define BT532_INTERRUPT_ENABLE          0x00F0
#define BT532_OPTIONAL_SETTING          0x0116
#define BT532_COVER_CONTROL             0x023E

#define BT532_VENDOR_COMMAND_ENABLE     0xC000
#define BT532_PROGRAM_START             0xC001
#define BT532_NVM_INIT                  0xC002
#define BT532_VENDOR_INTERRUPT_CLEAR    0xC004
#define BT532_CHIP_CODE_REGISTER        0xCC00

#define ZT7548_CHIP_CODE                0xE548

#define BT532_POINT_MODE_J6LTE          0
#define BT532_COVER_OPEN                0x0200
#define BT532_INTERRUPT_MASK            0x000F

#define BT532_STATUS_MUST_BE_ZERO       0x2000

#define BT532_SUB_EXIST                 0x01
#define BT532_SUB_DOWN                  0x02
#define BT532_SUB_MOVE                  0x04
#define BT532_SUB_UP                    0x08

#define BT532_CHIP_ON_DELAY_MS          15
#define BT532_FIRMWARE_ON_DELAY_MS      40
#define BT532_READ_RETRIES              10

#pragma pack(push, 1)
typedef struct _BT532_MODE0_POINT {
    USHORT X;
    USHORT Y;
    UCHAR Width;
    UCHAR SubStatus;
} BT532_MODE0_POINT;

typedef struct _BT532_MODE0_FRAME {
    USHORT Status;
    UCHAR FingerCount;
    UCHAR Timestamp;
    BT532_MODE0_POINT Points[J6_MAX_CONTACTS];
} BT532_MODE0_FRAME;
#pragma pack(pop)

C_ASSERT(sizeof(BT532_MODE0_POINT) == 6);
C_ASSERT(sizeof(BT532_MODE0_FRAME) == 34);

static
USHORT
ReadLe16(
    _In_reads_(2) const UCHAR* Buffer
    )
{
    return (USHORT)(Buffer[0] | ((USHORT)Buffer[1] << 8));
}

static
VOID
DelayMilliseconds(
    _In_ ULONG Milliseconds
    )
{
    LARGE_INTEGER interval;

    interval.QuadPart = -((LONGLONG)Milliseconds * 10 * 1000);
    (VOID)KeDelayExecutionThread(KernelMode, FALSE, &interval);
}

static
NTSTATUS
Bt532WriteCommand(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ USHORT Register
    )
{
    UCHAR packet[2];

    packet[0] = (UCHAR)(Register & 0xFF);
    packet[1] = (UCHAR)(Register >> 8);
    return SpbWrite(Context, packet, sizeof(packet));
}

static
NTSTATUS
Bt532WriteU16(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ USHORT Register,
    _In_ USHORT Value
    )
{
    UCHAR packet[4];

    packet[0] = (UCHAR)(Register & 0xFF);
    packet[1] = (UCHAR)(Register >> 8);
    packet[2] = (UCHAR)(Value & 0xFF);
    packet[3] = (UCHAR)(Value >> 8);
    return SpbWrite(Context, packet, sizeof(packet));
}

static
NTSTATUS
Bt532Read(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ USHORT Register,
    _Out_writes_bytes_(Length) UCHAR* Buffer,
    _In_ ULONG Length
    )
{
    UCHAR address[2];

    address[0] = (UCHAR)(Register & 0xFF);
    address[1] = (UCHAR)(Register >> 8);
    return SpbWriteRead(Context, address, sizeof(address), Buffer, Length);
}

static
NTSTATUS
Bt532ReadU16(
    _Inout_ PDEVICE_CONTEXT Context,
    _In_ USHORT Register,
    _Out_ USHORT* Value
    )
{
    UCHAR raw[2];
    NTSTATUS status;

    status = Bt532Read(Context, Register, raw, sizeof(raw));
    if (NT_SUCCESS(status)) {
        *Value = ReadLe16(raw);
    }

    return status;
}

static
NTSTATUS
Bt532PowerOnSequence(
    _Inout_ PDEVICE_CONTEXT Context
    )
{
    NTSTATUS status = STATUS_UNSUCCESSFUL;
    ULONG attempt;

    for (attempt = 0; attempt < 4; ++attempt) {
        status = Bt532WriteU16(Context, BT532_VENDOR_COMMAND_ENABLE, 1);
        if (!NT_SUCCESS(status)) {
            goto retry;
        }
        KeStallExecutionProcessor(10);

        status = Bt532ReadU16(Context, BT532_CHIP_CODE_REGISTER, &Context->ChipCode);
        if (!NT_SUCCESS(status)) {
            goto retry;
        }
        KeStallExecutionProcessor(10);

        status = Bt532WriteCommand(Context, BT532_VENDOR_INTERRUPT_CLEAR);
        if (!NT_SUCCESS(status)) {
            goto retry;
        }
        KeStallExecutionProcessor(10);

        status = Bt532WriteU16(Context, BT532_NVM_INIT, 1);
        if (!NT_SUCCESS(status)) {
            goto retry;
        }
        DelayMilliseconds(2);

        status = Bt532WriteU16(Context, BT532_PROGRAM_START, 1);
        if (!NT_SUCCESS(status)) {
            goto retry;
        }

        DelayMilliseconds(BT532_FIRMWARE_ON_DELAY_MS);
        return STATUS_SUCCESS;

retry:
        J6_TRACE_ERROR(
            "J6ZT7548: power sequence attempt %lu failed: 0x%08X\n",
            attempt + 1,
            status);
        DelayMilliseconds(BT532_CHIP_ON_DELAY_MS);
    }

    return status;
}

static
NTSTATUS
Bt532InitializeController(
    _Inout_ PDEVICE_CONTEXT Context
    )
{
    NTSTATUS status;
    ULONG index;

    status = Bt532WriteCommand(Context, BT532_SWRESET_CMD);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    status = Bt532ReadU16(Context, BT532_CHIP_REVISION, &Context->ChipRevision);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    status = Bt532ReadU16(Context, BT532_FIRMWARE_VERSION, &Context->FirmwareVersion);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    status = Bt532ReadU16(Context, BT532_MINOR_FIRMWARE_VERSION, &Context->FirmwareMinorVersion);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    status = Bt532ReadU16(Context, BT532_DATA_VERSION, &Context->RegisterDataVersion);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    status = Bt532WriteU16(Context, BT532_INTERRUPT_ENABLE, 0);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    // Samsung's production ZT7548 firmware for j6lte reports 34-byte mode-0
    // frames. Do not use the 44-byte generic mode-2 layout here.
    status = Bt532WriteU16(Context, BT532_TOUCH_MODE, BT532_POINT_MODE_J6LTE);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    status = Bt532WriteU16(Context, BT532_COVER_CONTROL, BT532_COVER_OPEN);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    status = Bt532WriteU16(Context, BT532_OPTIONAL_SETTING, 0);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    status = Bt532WriteU16(Context, BT532_INTERRUPT_ENABLE, BT532_INTERRUPT_MASK);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    for (index = 0; index < 10; ++index) {
        status = Bt532WriteCommand(Context, BT532_CLEAR_INT_STATUS_CMD);
        if (!NT_SUCCESS(status)) {
            return status;
        }
        KeStallExecutionProcessor(10);
    }

    return STATUS_SUCCESS;
}

NTSTATUS
Bt532Start(
    _Inout_ PDEVICE_CONTEXT Context
    )
{
    NTSTATUS status;

    Context->ControllerReady = FALSE;
    Context->ActiveContactMask = 0;
    RtlZeroMemory(Context->LastX, sizeof(Context->LastX));
    RtlZeroMemory(Context->LastY, sizeof(Context->LastY));

    if (!Context->HardwarePrepared) {
        return STATUS_INVALID_DEVICE_STATE;
    }

    // ACPI _PS0 must enable S2MPU05 LDO34 (3.3 V) before this callback.
    DelayMilliseconds(BT532_CHIP_ON_DELAY_MS);

    status = Bt532PowerOnSequence(Context);
    if (!NT_SUCCESS(status)) {
        J6SetDiagnosticValue(Context, L"PowerSequenceStatus", status);
        return status;
    }
    J6SetDiagnosticValue(Context, L"PowerSequenceStatus", STATUS_SUCCESS);
    J6SetDiagnosticValue(Context, L"ChipCode", Context->ChipCode);

    if (Context->ChipCode != ZT7548_CHIP_CODE) {
        J6_TRACE_ERROR(
            "J6ZT7548: expected chip code 0x%04X, received 0x%04X; continuing with BT532 protocol\n",
            ZT7548_CHIP_CODE,
            Context->ChipCode);
    }

    status = Bt532InitializeController(Context);
    if (!NT_SUCCESS(status)) {
        J6SetDiagnosticValue(Context, L"ControllerInitStatus", status);
        (VOID)Bt532WriteU16(Context, BT532_INTERRUPT_ENABLE, 0);
        return status;
    }
    J6SetDiagnosticValue(Context, L"ControllerInitStatus", STATUS_SUCCESS);
    J6SetDiagnosticValue(Context, L"ChipRevision", Context->ChipRevision);
    J6SetDiagnosticValue(Context, L"FirmwareVersion", Context->FirmwareVersion);
    J6SetDiagnosticValue(Context, L"FirmwareMinorVersion", Context->FirmwareMinorVersion);
    J6SetDiagnosticValue(Context, L"RegisterDataVersion", Context->RegisterDataVersion);

    J6_TRACE_INFO(
        "J6ZT7548: chip=0x%04X rev=0x%04X fw=0x%04X.%04X data=0x%04X\n",
        Context->ChipCode,
        Context->ChipRevision,
        Context->FirmwareVersion,
        Context->FirmwareMinorVersion,
        Context->RegisterDataVersion);

    Context->ControllerReady = TRUE;
    return STATUS_SUCCESS;
}

NTSTATUS
Bt532Stop(
    _Inout_ PDEVICE_CONTEXT Context
    )
{
    NTSTATUS firstStatus = STATUS_SUCCESS;
    NTSTATUS status;

    Context->ControllerReady = FALSE;
    Context->ActiveContactMask = 0;

    if (!Context->HardwarePrepared) {
        return STATUS_SUCCESS;
    }

    status = Bt532WriteU16(Context, BT532_INTERRUPT_ENABLE, 0);
    if (!NT_SUCCESS(status)) {
        firstStatus = status;
    }

    status = Bt532WriteCommand(Context, BT532_SLEEP_CMD);
    if (!NT_SUCCESS(status) && NT_SUCCESS(firstStatus)) {
        firstStatus = status;
    }

    return firstStatus;
}

static
BOOLEAN
Bt532FrameIsInvalid(
    _In_reads_bytes_(Length) const UCHAR* Frame,
    _In_ ULONG Length
    )
{
    USHORT status;
    ULONG offset;

    status = ReadLe16(Frame);
    if ((status & BT532_STATUS_MUST_BE_ZERO) != 0 || status == 0x0001) {
        return TRUE;
    }

    for (offset = 0; offset + 1 < Length; offset += 2) {
        if (ReadLe16(Frame + offset) == 0xFFFF) {
            return TRUE;
        }
    }

    return FALSE;
}

static
VOID
Bt532AppendContact(
    _Inout_ PJ6_TOUCH_INPUT_REPORT Report,
    _In_ UCHAR ContactId,
    _In_ BOOLEAN IsDown,
    _In_ USHORT X,
    _In_ USHORT Y
    )
{
    PJ6_TOUCH_CONTACT contact;

    if (Report->ContactCount >= J6_MAX_CONTACTS) {
        return;
    }

    contact = &Report->Contacts[Report->ContactCount];
    contact->Flags = J6_TOUCH_FLAG_CONFIDENCE;
    if (IsDown) {
        contact->Flags |= J6_TOUCH_FLAG_TIP;
    }
    contact->ContactId = ContactId;
    contact->X = min(X, (USHORT)J6_LOGICAL_MAX_X);
    contact->Y = min(Y, (USHORT)J6_LOGICAL_MAX_Y);
    ++Report->ContactCount;
}

NTSTATUS
Bt532ReadInputReport(
    _Inout_ PDEVICE_CONTEXT Context,
    _Out_ PJ6_TOUCH_INPUT_REPORT Report
    )
{
    UCHAR rawFrame[sizeof(BT532_MODE0_FRAME)];
    const BT532_MODE0_POINT* point;
    ULONG newMask = 0;
    ULONG releasedMask;
    ULONG attempt;
    ULONG index;
    NTSTATUS status = STATUS_DEVICE_DATA_ERROR;
    NTSTATUS clearStatus;

    RtlZeroMemory(Report, sizeof(*Report));
    Report->ReportId = J6_TOUCH_REPORT_ID;

    if (!Context->ControllerReady) {
        return STATUS_INVALID_DEVICE_STATE;
    }

    for (attempt = 0; attempt < BT532_READ_RETRIES; ++attempt) {
        status = Bt532Read(
            Context,
            BT532_POINT_STATUS,
            rawFrame,
            sizeof(rawFrame));
        if (!NT_SUCCESS(status)) {
            continue;
        }

        if (!Bt532FrameIsInvalid(rawFrame, sizeof(rawFrame))) {
            break;
        }

        status = STATUS_DEVICE_DATA_ERROR;
    }

    if (!NT_SUCCESS(status) || attempt == BT532_READ_RETRIES) {
        (VOID)Bt532WriteCommand(Context, BT532_CLEAR_INT_STATUS_CMD);
        return NT_SUCCESS(status) ? STATUS_DEVICE_DATA_ERROR : status;
    }

    for (index = 0; index < J6_MAX_CONTACTS; ++index) {
        UCHAR subStatus;
        USHORT x;
        USHORT y;

        point = (const BT532_MODE0_POINT*)(
            rawFrame + FIELD_OFFSET(BT532_MODE0_FRAME, Points) +
            index * sizeof(BT532_MODE0_POINT));
        subStatus = point->SubStatus;

        if ((subStatus & BT532_SUB_EXIST) == 0) {
            continue;
        }

        x = ReadLe16((const UCHAR*)&point->X);
        y = ReadLe16((const UCHAR*)&point->Y);
        Context->LastX[index] = min(x, (USHORT)J6_LOGICAL_MAX_X);
        Context->LastY[index] = min(y, (USHORT)J6_LOGICAL_MAX_Y);

        if ((subStatus & BT532_SUB_UP) == 0) {
            // EXIST is authoritative. DOWN/MOVE annotate the transition, but
            // a stationary contact may contain neither bit.
            newMask |= (1UL << index);
        }
    }

    releasedMask = Context->ActiveContactMask & ~newMask;

    // Parallel HID reports contain every active contact, followed by one-shot
    // lift records for contacts that disappeared in this controller frame.
    for (index = 0; index < J6_MAX_CONTACTS; ++index) {
        if ((newMask & (1UL << index)) != 0) {
            Bt532AppendContact(
                Report,
                (UCHAR)index,
                TRUE,
                Context->LastX[index],
                Context->LastY[index]);
        }
    }

    for (index = 0; index < J6_MAX_CONTACTS; ++index) {
        if ((releasedMask & (1UL << index)) != 0) {
            Bt532AppendContact(
                Report,
                (UCHAR)index,
                FALSE,
                Context->LastX[index],
                Context->LastY[index]);
        }
    }

    Context->ActiveContactMask = newMask;

    clearStatus = Bt532WriteCommand(Context, BT532_CLEAR_INT_STATUS_CMD);
    if (!NT_SUCCESS(clearStatus)) {
        return clearStatus;
    }

    return STATUS_SUCCESS;
}
