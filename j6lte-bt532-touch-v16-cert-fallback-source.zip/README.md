# j6lte Zinitix ZT7548 Windows touchscreen driver

ARM64 KMDF HID mini-driver for the touchscreen in the Samsung Galaxy J6
(`j6lte`). It translates the native Zinitix controller protocol into a
five-contact Windows touchscreen HID collection.

The supplied INF model targets **Windows 10 ARM64 build 19041 (2004) and later,
including Windows 11 ARM64**. The model section is decorated
`NTARM64.10.0...19041` and the KMDF version is 1.15. Microsoft introduced the
`MsHidKmdf.inf` Include/Needs contract in build 22000, however, so a Windows 10
deployment must provide that declarative compatibility INF before staging this
package. It uses Windows 10's own inbox `mshidkmdf.sys`; no Windows binary is
replaced. `scripts/build-winpe-media.ps1` supplies the INF automatically.
(Earlier driver builds also limited the model match itself to build 22000.)

## Current status

- ARM64 driver implementation: complete
- Windows HID descriptor and five-contact reporting: complete
- ZT7548 initialization and stock mode-0 frame parsing: complete
- Root-enumerated WinPE bootstrap for the known-booting Mu-Silicium firmware:
  included
- S5E7870 bootstrap MMIO transport and LDO34 control: complete
- WDK build validation: see the latest build output in `build/ARM64/Release`
- Physical-phone validation: **still required**

The development host is x64 and has no j6lte hardware attached, so a successful
build does not prove that the target's I2C, GPIO, PMIC, or ACPI integration is
correct. Do not deploy this as a boot-critical driver until it has been tested
with kernel debugging enabled.

## Identified hardware

Samsung's production source and the close-to-mainline device tree agree on the
electrical connection. The production source provides the more specific chip
identity and frame mode:

| Property | Value |
|---|---|
| Controller | Zinitix **ZT7548**, BT532-family protocol |
| Expected chip code | `0xE548` |
| I2C controller | Exynos `i2c@13890000` (mainline alias `i2c6`) |
| I2C address/speed | 7-bit `0x20`, 400 kHz |
| Interrupt | `GPA0-6`, level-low |
| Windows GPIO mapping | `\_SB.GPI0`, pin 22, EINT function `0x0F` |
| Touch power | S2MPU05 LDO34, 3.3 V |
| Native resolution | 720 x 1480 (logical maxima 719 x 1479) |
| Contacts | 5 |
| Firmware point mode | mode 0, 34-byte frame |

## What the driver does

- Maps only the fixed MMIO resources assigned by the j6lte ACPI device.
- Enables S2MPU05 LDO34 at 3.3 V through HSI2C0.
- Configures the S5E7870 I2C6/GPC2 pins and performs native ZT7548 transfers.
- Runs the Zinitix vendor/NVM/program-start power sequence.
- Reads and logs chip, firmware, and register-data versions.
- Selects the stock J6 mode-0 report format and enables down/move/up interrupts.
- Polls active-low GPA0-6 every 8 ms because Mu-Silicium currently exposes no
  Windows GpioClx controller.
- Preserves contact IDs and emits explicit one-frame lift records.
- Exposes the mandatory Windows touchscreen HID usages and maximum-contact
  feature report.
- Queues up to 32 reports if HIDClass temporarily has no pending read.

It intentionally does **not** flash firmware, implement Samsung factory tests,
or enable always-on-display/payment gestures. Those are unsafe or unnecessary
for initial Windows bring-up.

## Build

Required toolchain:

- Visual Studio 2022 Build Tools with the v143 ARM64 compiler
- Windows SDK 10.0.26100
- Windows Driver Kit 10.0.26100

From PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File ./scripts/check-toolchain.ps1
powershell -ExecutionPolicy Bypass -File ./scripts/build.ps1 -Configuration Release -Platform ARM64 -Rebuild
powershell -ExecutionPolicy Bypass -File ./scripts/validate-acpi.ps1
```

The package is emitted under:

```text
build/ARM64/Release/J6LteBt532Touch/
```

`build/ARM64/Release/J6LteBt532Touch-arm64-test.zip` contains the same
test-signed INF/SYS/CAT/CER set for transfer to the phone.

### Building against the Windows 10 2004 (19041) WDK

The default build uses whatever WDK is installed (10.0.26100 here), which is
the Windows 11 toolchain. To reproduce the driver with the toolchain that
matches the Windows 10 IoT Enterprise LTSC 2021 target, use the standalone
scripts:

```powershell
powershell -ExecutionPolicy Bypass -File ./scripts/build-wdk19041.ps1 `
    -Wdk19041 'C:\path\to\extracted\Windows Kits\10' `
    -SdkShared 'C:\Program Files (x86)\Windows Kits\10\Include\10.0.26100.0\shared'

powershell -ExecutionPolicy Bypass -File ./scripts/pack-wdk19041.ps1 `
    -CertificateThumbprint <test-cert-thumbprint>
```

`build-wdk19041.ps1` expects a WDK 10.0.19041.685 layout extracted with
`msiexec /a` (no administrator rights required). Output goes to
`build/ARM64/wdk19041/`. The resulting binary imports exactly the same
modules and symbols as the 26100 build (`ntoskrnl.exe`, `HAL.dll`,
`WDFLDR.SYS` with KMDF 1.15 binding), so it is a drop-in replacement.

**The released `20.11.14.1` package is produced by these two scripts**, i.e.
the shipped SYS comes from the Windows 10 19041 WDK, not from the MSBuild
default. `$DriverVersion` in `pack-wdk19041.ps1` and the `TimeStamp` in
`J6LteBt532Touch.vcxproj` must be kept in step.

## Mu-Silicium integration

The upstream gtaxllte Mu-Silicium DSDT exposes CPUs and eMMC but no Windows
I2C/GPIO controller or touchscreen. Merely changing its device name and display
resolution cannot enumerate this driver.

For first hardware bring-up, version 1.1 uses a board-specific bootstrap
transport instead of depending on controller drivers that do not exist yet.
The preferred WinPE path keeps the already-known-booting, resolution-modified
gtaxllte firmware unchanged. After `wpeinit`, `J6CreateDevice.exe` creates
`ROOT\J6ZT7548` and installs the driver; the driver then maps the documented
j6lte MMIO addresses directly.

An earlier experiment added a dedicated `j6ltePkg` and seven new UEFI memory
descriptors. Windows Boot Manager failed in `BlInitializeLibrary` with
`0xC0000225`, consistent with firmware memory-map fragmentation. That overlay
is retained under `firmware/Mu-Silicium` for analysis only and must not be
flashed in its current form.

The INF accepts `ROOT\J6ZT7548` as well as ACPI IDs `ZTX7548` and `ZTX5320`.
Do not install this bootstrap driver on another Exynos board: it intentionally
controls j6lte's fixed clock, pin, I2C, PMIC, and GPIO registers. A production
implementation should replace this transport with native SpbCx/GpioClx
controller drivers.

## Install on an ARM64 target

The package must be signed. For development, configure the target for test
signing and disable Secure Boot if the platform requires it. Do this only on a
recoverable development installation:

```console
bcdedit /set testsigning on
```

After rebooting, stage the built package from an elevated ARM64 PowerShell:

```powershell
./scripts/install-on-target.ps1 -PackageDirectory ./build/ARM64/Release/J6LteBt532Touch
```

The development build script places its public WDK test certificate in the
package directory. Local Machine Root trust is mandatory. Trusted Publisher is
also attempted, but is best-effort because Windows 10 can deny that store during
`SetupComplete` with `0x80070005`; the package is already staged with
`/ForceUnsigned` and the target boots with TESTSIGNING. Use this behavior only
on a test device.

See `docs/TESTING.md` before first deployment. A production image requires a
properly signed catalog rather than test-signing mode.

## References

- [Exynos 7870 mainline Linux tree](https://gitlab.com/exynos7870-mainline/linux)
- [WOA-Project/FakeTouch](https://github.com/WOA-Project/FakeTouch) (architecture reference only)
- [Microsoft KMDF virtual HID sample](https://github.com/microsoft/Windows-driver-samples/tree/main/hid/vhidmini2)
- [Windows touchscreen HID requirements](https://learn.microsoft.com/windows-hardware/design/component-guidelines/touchscreen-required-hid-top-level-collections)
