#requires -version 5.1
<#
    pack-wdk19041.ps1 - turn a build-wdk19041.ps1 driver binary into a signed,
    installable ARM64 driver package.

    Steps
    -----
    1. stampinf on J6LteBt532Touch.inx (pinned DriverVer + KMDF 1.15)
    2. Inf2Cat for Windows 10 client, Windows 11 client and Server ARM64
    3. signtool for SYS and CAT (test certificate, same as the normal build)

    Usage
    -----
    powershell -ExecutionPolicy Bypass -File scripts\pack-wdk19041.ps1 `
        -CertificateThumbprint <thumbprint>
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$CertificateThumbprint,

    [string]$WindowsKitsRoot = (Join-Path ${env:ProgramFiles(x86)} 'Windows Kits\10'),
    [string]$DriverVersion = '20.11.14.1',
    [string]$DriverDate = '11/13/2026',
    [string]$KmdfVersion = '1.15'
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$sourceDir = Join-Path $root 'driver'
$inDir = Join-Path $root 'build\ARM64\wdk19041'
$outDir = Join-Path $inDir 'package'

$sysIn = Join-Path $inDir 'J6LteBt532Touch.sys'
if (-not (Test-Path $sysIn)) { throw "Run scripts\build-wdk19041.ps1 first; $sysIn is missing." }

$binRoot = Get-ChildItem (Join-Path $WindowsKitsRoot 'bin') -Directory |
    Where-Object { $_.Name -match '^10\.' } | Sort-Object Name -Descending | Select-Object -First 1
$bin = Join-Path $binRoot.FullName 'x86'
foreach ($tool in @('stampinf.exe', 'Inf2Cat.exe', 'signtool.exe')) {
    if (-not (Test-Path (Join-Path $bin $tool))) { throw "$tool was not found in $bin" }
}

$cert = Get-ChildItem "Cert:\CurrentUser\My\$CertificateThumbprint" -ErrorAction SilentlyContinue
if (-not $cert) { throw "Certificate $CertificateThumbprint was not found in Cert:\CurrentUser\My." }

if (Test-Path $outDir) { Remove-Item $outDir -Recurse -Force }
New-Item -ItemType Directory -Path $outDir -Force | Out-Null

Copy-Item $sysIn (Join-Path $outDir 'J6LteBt532Touch.sys') -Force
$inf = Join-Path $outDir 'J6LteBt532Touch.inf'
Copy-Item (Join-Path $sourceDir 'J6LteBt532Touch.inx') $inf -Force

Write-Host '== signing the SYS'
# The catalog records a hash of the finished SYS file, so the binary must be
# signed *before* Inf2Cat runs. The MSBuild WDK targets do the same.
& (Join-Path $bin 'signtool.exe') sign /v /fd sha256 /sha1 $CertificateThumbprint /a (Join-Path $outDir 'J6LteBt532Touch.sys')
if ($LASTEXITCODE -ne 0) { throw 'Signing the SYS failed.' }

Write-Host '== stampinf'
& (Join-Path $bin 'stampinf.exe') -f $inf -d $DriverDate -v $DriverVersion -k $KmdfVersion -a arm64
if ($LASTEXITCODE -ne 0) { throw 'stampinf failed.' }

Write-Host '== Inf2Cat'
& (Join-Path $bin 'Inf2Cat.exe') /driver:$outDir `
    /os:10_VB_ARM64,10_CO_ARM64,10_GE_ARM64,Server10_ARM64 /verbose /uselocaltime
if ($LASTEXITCODE -ne 0) { throw 'Inf2Cat failed.' }

Write-Host '== signing the CAT'
& (Join-Path $bin 'signtool.exe') sign /v /fd sha256 /sha1 $CertificateThumbprint /a (Join-Path $outDir 'J6LteBt532Touch.cat')
if ($LASTEXITCODE -ne 0) { throw 'Signing the CAT failed.' }

[IO.File]::WriteAllBytes((Join-Path $outDir 'J6LteBt532Touch.cer'), $cert.Export('Cert'))

Get-ChildItem $outDir -File |
    Select-Object Name, Length, @{N = 'SHA256'; E = { (Get-FileHash $_.FullName -Algorithm SHA256).Hash } } |
    Format-Table -AutoSize
