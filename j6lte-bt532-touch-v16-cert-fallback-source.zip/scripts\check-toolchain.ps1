$ErrorActionPreference = 'Stop'
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'

if (Test-Path $vswhere) {
    & $vswhere -latest -products * -format json
} else {
    Write-Warning 'vswhere.exe not found'
}

$kitsRoot = Join-Path ${env:ProgramFiles(x86)} 'Windows Kits\10'
Write-Host "`nInstalled Windows kit include versions:"
Get-ChildItem (Join-Path $kitsRoot 'Include') -Directory -ErrorAction SilentlyContinue |
    Select-Object -ExpandProperty Name

Write-Host "`nARM64 compiler tools:"
Get-ChildItem (Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC') -Directory -ErrorAction SilentlyContinue |
    ForEach-Object {
        Join-Path $_.FullName 'bin\Hostx64\arm64\cl.exe'
    } |
    Where-Object { Test-Path $_ }
