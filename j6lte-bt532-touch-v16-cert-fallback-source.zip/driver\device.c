#include "driver.h"

VOID
J6SetDiagnosticValue(
    _In_ PDEVICE_CONTEXT Context,
    _In_z_ PCWSTR Name,
    _In_ ULONG Value
    )
{
    WDFKEY key;
    UNICODE_STRING valueName;
    NTSTATUS status;

    if (Context == NULL || Context->Device == NULL || Name == NULL) {
        return;
    }

    status = WdfDriverOpenParametersRegistryKey(
        WdfDeviceGetDriver(Context->Device),
        KEY_SET_VALUE,
        WDF_NO_OBJECT_ATTRIBUTES,
        &key);
    if (!NT_SUCCESS(status)) {
        return;
    }

    RtlInitUnicodeString(&valueName, Name);
    (VOID)WdfRegistryAssignULong(key, &valueName, Value);
    WdfRegistryClose(key);
}

NTSTATUS
J6EvtDeviceAdd(
    _In_ WDFDRIVER Driver,
    _Inout_ PWDFDEVICE_INIT DeviceInit
    )
{
    WDF_OBJECT_ATTRIBUTES deviceAttributes;
    WDF_OBJECT_ATTRIBUTES objectAttributes;
    WDF_OBJECT_ATTRIBUTES queueAttributes;
    WDF_PNPPOWER_EVENT_CALLBACKS powerCallbacks;
    WDF_IO_QUEUE_CONFIG queueConfig;
    WDF_TIMER_CONFIG timerConfig;
    WDF_OBJECT_ATTRIBUTES timerAttributes;
    PDEVICE_CONTEXT context;
    WDFDEVICE device;
    NTSTATUS status;

    UNREFERENCED_PARAMETER(Driver);

    // MsHidKmdf is the HID function driver; this KMDF HID mini-driver is its
    // lower filter and must not own power policy.
    WdfFdoInitSetFilter(DeviceInit);

    WDF_PNPPOWER_EVENT_CALLBACKS_INIT(&powerCallbacks);
    powerCallbacks.EvtDevicePrepareHardware = J6EvtDevicePrepareHardware;
    powerCallbacks.EvtDeviceReleaseHardware = J6EvtDeviceReleaseHardware;
    powerCallbacks.EvtDeviceD0Entry = J6EvtDeviceD0Entry;
    powerCallbacks.EvtDeviceD0Exit = J6EvtDeviceD0Exit;
    WdfDeviceInitSetPnpPowerEventCallbacks(DeviceInit, &powerCallbacks);

    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&deviceAttributes, DEVICE_CONTEXT);
    deviceAttributes.ExecutionLevel = WdfExecutionLevelPassive;
    deviceAttributes.SynchronizationScope = WdfSynchronizationScopeNone;

    status = WdfDeviceCreate(&DeviceInit, &deviceAttributes, &device);
    if (!NT_SUCCESS(status)) {
        J6_TRACE_ERROR("J6ZT7548: WdfDeviceCreate failed: 0x%08X\n", status);
        return status;
    }

    context = DeviceGetContext(device);
    context->Device = device;
    HidInitializeState(context);
    J6SetDiagnosticValue(context, L"Stage", 1);
    J6SetDiagnosticValue(context, L"LastStatus", STATUS_SUCCESS);

    WDF_OBJECT_ATTRIBUTES_INIT(&objectAttributes);
    objectAttributes.ParentObject = device;

    status = WdfWaitLockCreate(&objectAttributes, &context->SpbLock);
    if (!NT_SUCCESS(status)) {
        J6SetDiagnosticValue(context, L"Stage", 0x80000002);
        J6SetDiagnosticValue(context, L"LastStatus", status);
        J6_TRACE_ERROR("J6ZT7548: failed to create SPB lock: 0x%08X\n", status);
        return status;
    }
    J6SetDiagnosticValue(context, L"Stage", 2);

    status = WdfWaitLockCreate(&objectAttributes, &context->ReportLock);
    if (!NT_SUCCESS(status)) {
        J6SetDiagnosticValue(context, L"Stage", 0x80000003);
        J6SetDiagnosticValue(context, L"LastStatus", status);
        J6_TRACE_ERROR("J6ZT7548: failed to create report lock: 0x%08X\n", status);
        return status;
    }
    J6SetDiagnosticValue(context, L"Stage", 3);

    WDF_IO_QUEUE_CONFIG_INIT_DEFAULT_QUEUE(
        &queueConfig,
        WdfIoQueueDispatchParallel);
    queueConfig.EvtIoInternalDeviceControl = J6EvtIoInternalDeviceControl;
    queueConfig.PowerManaged = WdfFalse;

    WDF_OBJECT_ATTRIBUTES_INIT(&queueAttributes);
    queueAttributes.ExecutionLevel = WdfExecutionLevelPassive;

    status = WdfIoQueueCreate(
        device,
        &queueConfig,
        &queueAttributes,
        &context->DefaultQueue);
    if (!NT_SUCCESS(status)) {
        J6SetDiagnosticValue(context, L"Stage", 0x80000004);
        J6SetDiagnosticValue(context, L"LastStatus", status);
        J6_TRACE_ERROR("J6ZT7548: failed to create HID queue: 0x%08X\n", status);
        return status;
    }
    J6SetDiagnosticValue(context, L"Stage", 4);

    WDF_IO_QUEUE_CONFIG_INIT(&queueConfig, WdfIoQueueDispatchManual);
    queueConfig.PowerManaged = WdfFalse;

    WDF_OBJECT_ATTRIBUTES_INIT(&queueAttributes);
    queueAttributes.ExecutionLevel = WdfExecutionLevelPassive;

    status = WdfIoQueueCreate(
        device,
        &queueConfig,
        &queueAttributes,
        &context->ReadQueue);
    if (!NT_SUCCESS(status)) {
        J6SetDiagnosticValue(context, L"Stage", 0x80000005);
        J6SetDiagnosticValue(context, L"LastStatus", status);
        J6_TRACE_ERROR("J6ZT7548: failed to create read queue: 0x%08X\n", status);
        return status;
    }
    J6SetDiagnosticValue(context, L"Stage", 5);

    // KMDF does not support periodic PASSIVE_LEVEL timers.  Use a passive
    // one-shot timer and rearm it from J6EvtPollTimer after each poll.
    WDF_TIMER_CONFIG_INIT(&timerConfig, J6EvtPollTimer);
    timerConfig.AutomaticSerialization = FALSE;

    WDF_OBJECT_ATTRIBUTES_INIT(&timerAttributes);
    timerAttributes.ParentObject = device;
    timerAttributes.ExecutionLevel = WdfExecutionLevelPassive;

    status = WdfTimerCreate(
        &timerConfig,
        &timerAttributes,
        &context->PollTimer);
    if (!NT_SUCCESS(status)) {
        J6SetDiagnosticValue(context, L"Stage", 0x80000006);
        J6SetDiagnosticValue(context, L"LastStatus", status);
        J6_TRACE_ERROR("J6ZT7548: failed to create polling timer: 0x%08X\n", status);
        return status;
    }

    J6SetDiagnosticValue(context, L"Stage", 7);
    J6SetDiagnosticValue(context, L"LastStatus", STATUS_SUCCESS);

    return STATUS_SUCCESS;
}

NTSTATUS
J6EvtDevicePrepareHardware(
    _In_ WDFDEVICE Device,
    _In_ WDFCMRESLIST ResourcesRaw,
    _In_ WDFCMRESLIST ResourcesTranslated
    )
{
    PDEVICE_CONTEXT context = DeviceGetContext(Device);
    NTSTATUS status;

    UNREFERENCED_PARAMETER(ResourcesRaw);

    J6SetDiagnosticValue(context, L"Stage", 10);
    status = SpbTargetOpen(context, ResourcesTranslated);
    J6SetDiagnosticValue(context, L"PrepareHardwareStatus", status);
    J6SetDiagnosticValue(context, L"LastStatus", status);
    J6SetDiagnosticValue(context, L"Stage", NT_SUCCESS(status) ? 11 : 0x8000000A);
    return status;
}

NTSTATUS
J6EvtDeviceReleaseHardware(
    _In_ WDFDEVICE Device,
    _In_ WDFCMRESLIST ResourcesTranslated
    )
{
    PDEVICE_CONTEXT context = DeviceGetContext(Device);

    UNREFERENCED_PARAMETER(ResourcesTranslated);

    context->ControllerReady = FALSE;
    (VOID)WdfTimerStop(context->PollTimer, TRUE);
    HidFlushReports(context);
    SpbTargetClose(context);
    return STATUS_SUCCESS;
}

NTSTATUS
J6EvtDeviceD0Entry(
    _In_ WDFDEVICE Device,
    _In_ WDF_POWER_DEVICE_STATE PreviousState
    )
{
    PDEVICE_CONTEXT context = DeviceGetContext(Device);
    NTSTATUS status;

    UNREFERENCED_PARAMETER(PreviousState);

    HidFlushReports(context);
    J6SetDiagnosticValue(context, L"Stage", 20);
    status = Bt532Start(context);
    J6SetDiagnosticValue(context, L"ControllerStartStatus", status);
    J6SetDiagnosticValue(context, L"LastStatus", status);
    if (!NT_SUCCESS(status)) {
        J6SetDiagnosticValue(context, L"Stage", 0x80000014);
        J6_TRACE_ERROR("J6ZT7548: controller start failed: 0x%08X\n", status);
    } else {
        context->ConsecutiveReadFailures = 0;
        context->InputReportSeen = FALSE;
        J6SetDiagnosticValue(context, L"Stage", 21);
        (VOID)WdfTimerStart(context->PollTimer, WDF_REL_TIMEOUT_IN_MS(1));
    }

    return status;
}

NTSTATUS
J6EvtDeviceD0Exit(
    _In_ WDFDEVICE Device,
    _In_ WDF_POWER_DEVICE_STATE TargetState
    )
{
    PDEVICE_CONTEXT context = DeviceGetContext(Device);
    NTSTATUS status;

    UNREFERENCED_PARAMETER(TargetState);

    // Prevent the passive one-shot callback from rearming while Stop waits
    // for an in-progress poll to finish.
    context->ControllerReady = FALSE;
    (VOID)WdfTimerStop(context->PollTimer, TRUE);
    status = Bt532Stop(context);
    HidFlushReports(context);

    // A failed best-effort sleep command must not block system power-down.
    if (!NT_SUCCESS(status)) {
        J6_TRACE_ERROR("J6ZT7548: controller stop failed: 0x%08X\n", status);
        status = STATUS_SUCCESS;
    }

    return status;
}

VOID
J6EvtPollTimer(
    _In_ WDFTIMER Timer
    )
{
    PDEVICE_CONTEXT context;
    J6_TOUCH_INPUT_REPORT report;
    NTSTATUS status;

    context = DeviceGetContext((WDFDEVICE)WdfTimerGetParentObject(Timer));
    if (!context->ControllerReady) {
        return;
    }

    // ZT7548 drives GPA0-6 low while a point frame is pending.  Reading only
    // while asserted avoids treating the controller's idle pattern as data.
    if (SpbTouchInterruptAsserted(context)) {
        status = Bt532ReadInputReport(context, &report);
        if (NT_SUCCESS(status)) {
            context->ConsecutiveReadFailures = 0;
            if (!context->InputReportSeen) {
                context->InputReportSeen = TRUE;
                J6SetDiagnosticValue(context, L"FirstInputStatus", STATUS_SUCCESS);
                J6SetDiagnosticValue(context, L"Stage", 30);
            }
            if (HidInputReportChanged(context, &report)) {
                status = HidQueueInputReport(context, &report);
                if (!NT_SUCCESS(status)) {
                    J6_TRACE_ERROR("J6ZT7548: failed to queue HID report: 0x%08X\n", status);
                }
            }
        } else {
            ++context->ConsecutiveReadFailures;
            if (context->ConsecutiveReadFailures == 1) {
                J6SetDiagnosticValue(context, L"FirstInputStatus", status);
                J6SetDiagnosticValue(context, L"Stage", 0x8000001E);
            }
            if (context->ConsecutiveReadFailures == 1 ||
                (context->ConsecutiveReadFailures % 128) == 0) {
                J6_TRACE_ERROR(
                    "J6ZT7548: polling read failed (%lu consecutive): 0x%08X\n",
                    context->ConsecutiveReadFailures,
                    status);
            }
        }
    }

    // A passive timer must be one-shot.  Rearm only while the controller is
    // active; D0Exit clears ControllerReady before synchronously stopping it.
    if (context->ControllerReady) {
        (VOID)WdfTimerStart(Timer, WDF_REL_TIMEOUT_IN_MS(8));
    }
}
