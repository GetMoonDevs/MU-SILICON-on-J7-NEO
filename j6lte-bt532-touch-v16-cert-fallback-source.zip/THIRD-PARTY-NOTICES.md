# Third-party notices and protocol references

This implementation was written as a new driver and is licensed under MIT.
The following projects and documentation were used to understand public APIs,
hardware wiring, and the controller protocol:

1. **Microsoft Windows Driver Samples — `hid/vhidmini2`**  
   <https://github.com/microsoft/Windows-driver-samples>  
   MIT License. Used as the reference for current `MsHidKmdf` INF integration
   and HID mini-driver request handling.

2. **Linux Zinitix touchscreen driver**  
   <https://gitlab.com/exynos7870-mainline/linux>  
   GPL-2.0-only. Used as protocol documentation for public register addresses,
   transaction ordering, and j6lte device-tree wiring.

3. **Samsung j6lte downstream kernel source**  
   <https://github.com/Oxygen-Kernel/j6lte>  
   Used to identify the production controller as ZT7548 (`0xE548`), its stock
   mode-0 frame format, and its power sequence.

4. **WOA-Project/FakeTouch**  
   <https://github.com/WOA-Project/FakeTouch>  
   Reviewed as a high-level touch-driver architecture reference. Its source was
   not copied into this project.

5. **Exynos7870 Windows Drivers**  
   <https://github.com/AistopGit/Exynos7870-Windows-Drivers>  
   MIT License. Used to determine the Windows GPIO namespace/pin mapping and
   vendor pin-function encoding for GPA0-6.

6. **Project-Silicium/Mu-Silicium and Silicium-ACPI**  
   <https://github.com/Project-Silicium/Mu-Silicium>  
   <https://github.com/Project-Silicium/Silicium-ACPI>  
   BSD-2-Clause. The supplied j6lte platform overlay is derived from the
   project's gtaxllte S5E7870 platform layout.

7. **Linux S3C24xx I2C controller driver**  
   <https://github.com/torvalds/linux/blob/master/drivers/i2c/busses/i2c-s3c2410.c>  
   GPL-2.0-or-later. Used as hardware documentation for the public S3C2440 I2C
   register definitions and controller sequencing; no Linux source is linked
   into the Windows binary.
