$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$source = Join-Path $root 'acpi\j6lte-zt7548.asl'
$outputDirectory = Join-Path $root 'build\acpi'
$output = Join-Path $outputDirectory 'j6lte-zt7548.aml'
$kitsRoot = Join-Path ${env:ProgramFiles(x86)} 'Windows Kits\10\Tools'

$asl = Get-ChildItem $kitsRoot -Recurse -Filter asl.exe -ErrorAction SilentlyContinue |
    Where-Object FullName -Match '\\x64\\ACPIVerify\\asl\.exe$' |
    Sort-Object FullName -Descending |
    Select-Object -First 1

if (-not $asl) {
    throw 'The x64 WDK ACPI ASL compiler was not found.'
}

New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
& $asl.FullName /nologo "/Fo=$output" $source
if ($LASTEXITCODE -ne 0) {
    throw "ASL validation failed with exit code $LASTEXITCODE."
}

Write-Host "Validated ACPI template: $output"
