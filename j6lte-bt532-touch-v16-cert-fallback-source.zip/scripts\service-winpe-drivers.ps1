[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$WimPath,

    [Parameter(Mandatory)]
    [string]$MountDirectory,

    [Parameter(Mandatory)]
    [string]$TouchInf,

    [Parameter(Mandatory)]
    [string]$StorageInf
)

$ErrorActionPreference = 'Stop'
$dism = Join-Path ${env:ProgramFiles(x86)} 'Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\DISM\dism.exe'

foreach ($path in @($WimPath, $MountDirectory, $TouchInf, $StorageInf, $dism)) {
    if (-not (Test-Path -LiteralPath $path)) {
        throw "Required path not found: $path"
    }
}

$children = @(Get-ChildItem -LiteralPath $MountDirectory -Force -ErrorAction SilentlyContinue)
if ($children.Count -ne 0) {
    throw "Mount directory is not empty: $MountDirectory"
}

$mounted = $false
try {
    & $dism /English /Mount-Image "/ImageFile:$WimPath" /Index:1 "/MountDir:$MountDirectory" /Optimize
    if ($LASTEXITCODE -ne 0) { throw "DISM mount failed: $LASTEXITCODE" }
    $mounted = $true

    $driverInfo = & $dism /English "/Image:$MountDirectory" /Get-Drivers /Format:Table 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0) { throw "Driver enumeration failed: $LASTEXITCODE" }

    foreach ($originalName in @('j6ltebt532touch.inf', 'dwcmshc.inf')) {
        $match = [regex]::Match(
            $driverInfo,
            "(?im)^\s*(oem\d+\.inf)\s+\|\s+$([regex]::Escape($originalName))\s+\|")
        if ($match.Success) {
            & $dism /English "/Image:$MountDirectory" /Remove-Driver "/Driver:$($match.Groups[1].Value)"
            if ($LASTEXITCODE -ne 0) { throw "Removing $originalName failed: $LASTEXITCODE" }
        }
    }

    foreach ($inf in @($TouchInf, $StorageInf)) {
        & $dism /English "/Image:$MountDirectory" /Add-Driver "/Driver:$inf" /ForceUnsigned
        if ($LASTEXITCODE -ne 0) { throw "Adding $inf failed: $LASTEXITCODE" }
    }

    $finalInfo = & $dism /English "/Image:$MountDirectory" /Get-Drivers /Format:Table 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0) { throw "Final driver enumeration failed: $LASTEXITCODE" }
    if ($finalInfo -notmatch '(?i)j6ltebt532touch\.inf' -or
        $finalInfo -notmatch '(?i)dwcmshc\.inf') {
        throw 'Final offline image does not contain both required drivers.'
    }

    & $dism /English /Unmount-Image "/MountDir:$MountDirectory" /Commit
    if ($LASTEXITCODE -ne 0) { throw "DISM commit failed: $LASTEXITCODE" }
    $mounted = $false
} finally {
    if ($mounted) {
        & $dism /English /Unmount-Image "/MountDir:$MountDirectory" /Discard
    }
}

Write-Host 'Touch and Exynos7870 eMMC drivers serviced into WinPE.'
