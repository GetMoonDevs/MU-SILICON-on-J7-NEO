@echo off
rem ===========================================================================
rem  J6Touch - touch + eMMC diagnostic collector (Windows PE build)
rem
rem  Read-only: it queries the driver, PnP and storage state and writes
rem      %SystemRoot%\Temp\J6TouchDiag.txt
rem      <drive>:\J6TouchDiag.txt   (every readable volume)
rem
rem  Usage:  J6TouchDiag.cmd [--pause]
rem ===========================================================================
setlocal EnableExtensions EnableDelayedExpansion

set "ROOT=X:\J6Touch"
if not exist "%ROOT%\tools\J6Diag.exe" for %%I in ("%~dp0.") do set "ROOT=%%~fI"
set "TOOLS=%ROOT%\tools"
set "OUT=%SystemRoot%\Temp\J6TouchDiag.txt"
set "PARAMS=HKLM\SYSTEM\CurrentControlSet\Services\J6LteBt532Touch\Parameters"
set "SETUPAPI=%SystemRoot%\INF\setupapi.dev.log"
set "DP=%SystemRoot%\Temp\J6DiskPart.txt"

echo.
echo Collecting J6 diagnostics, please wait...
echo Tap the phone screen repeatedly during this countdown so the driver
echo has a chance to record its first input frame.
for /l %%S in (8,-1,1) do (
    echo   %%S...
    ping.exe 127.0.0.1 -n 2 -w 1000 >nul 2>&1
)
echo.

>"%OUT%" echo ============================================================
>>"%OUT%" echo  J6 (SM-J600G) touch + eMMC diagnostics - Windows PE
>>"%OUT%" echo ============================================================
>>"%OUT%" echo When        : %DATE% %TIME%
>>"%OUT%" echo Payload     : %ROOT%
>>"%OUT%" echo.

rem ---------------------------------------------------------------- boot policy
>>"%OUT%" echo --- Boot policy (testsigning must be Yes) ---
if exist "%SystemRoot%\Temp\J6Bcd.txt" (
    findstr /i /c:"testsigning" /c:"nointegritychecks" "%SystemRoot%\Temp\J6Bcd.txt" >>"%OUT%" 2>&1
) else (
    bcdedit.exe /enum all >"%SystemRoot%\Temp\J6Bcd.txt" 2>&1
    findstr /i /c:"testsigning" /c:"nointegritychecks" "%SystemRoot%\Temp\J6Bcd.txt" >>"%OUT%" 2>&1
)
>>"%OUT%" echo.

rem ---------------------------------------------------------------- driver state
>>"%OUT%" echo --- Driver state (J6Diag) ---
if exist "%TOOLS%\J6Diag.exe" (
    "%TOOLS%\J6Diag.exe" >>"%OUT%" 2>&1
) else (
    >>"%OUT%" echo J6Diag.exe missing from %TOOLS%
)
>>"%OUT%" echo.

rem ---------------------------------------------------------------- verdict
set "STAGE=unknown"
set "CHIP=unknown"
for /f "tokens=3" %%A in ('reg query "%PARAMS%" /v Stage 2^>nul ^| findstr /i "REG_DWORD"') do set "STAGE=%%A"
for /f "tokens=3" %%A in ('reg query "%PARAMS%" /v ChipCode 2^>nul ^| findstr /i "REG_DWORD"') do set "CHIP=%%A"

>>"%OUT%" echo --- Verdict ---
>>"%OUT%" echo Stage       : !STAGE!      (0x1E / 30 = first touch frame read OK)
>>"%OUT%" echo Chip code   : !CHIP!      (expect 0xE548)
if /i "!STAGE!"=="0x1e" (
    >>"%OUT%" echo Result      : PASS - driver is running and streaming touch frames.
) else if /i "!STAGE!"=="unknown" (
    >>"%OUT%" echo Result      : driver never started - no Parameters key.
    >>"%OUT%" echo               Check the install log and section 3 below.
) else (
    >>"%OUT%" echo Result      : driver started but did not reach the frame loop.
    >>"%OUT%" echo               0x80000002-0x80000006 = KMDF object/queue/timer failure
    >>"%OUT%" echo               0x8000000A = SpbTargetOpen failed
    >>"%OUT%" echo               0x80000014 = Bt532Start failed
    >>"%OUT%" echo               0x8000001E = first input report failed
)
>>"%OUT%" echo Note: pointer behavior varies in customized WinPE shells. The
>>"%OUT%" echo       driver-written Stage value above is the authoritative test.
>>"%OUT%" echo.

rem ---------------------------------------------------------------- services
>>"%OUT%" echo --- Services ---
for %%S in (J6LteBt532Touch mshidkmdf dwcmshc) do (
    reg query "HKLM\SYSTEM\CurrentControlSet\Services\%%S" >>"%OUT%" 2>&1
)
if exist "%SystemRoot%\INF\MsHidKmdf.inf" (
    >>"%OUT%" echo MsHidKmdf.inf: present
    findstr /i /b /c:"DriverVer" "%SystemRoot%\INF\MsHidKmdf.inf" >>"%OUT%" 2>&1
) else (
    >>"%OUT%" echo MsHidKmdf.inf: MISSING - touch Include/Needs cannot resolve
)
>>"%OUT%" echo.

rem ---------------------------------------------------------------- problem devices
>>"%OUT%" echo --- Devices with problems ---
pnputil.exe /enum-devices /problem >>"%OUT%" 2>&1
>>"%OUT%" echo.

rem ---------------------------------------------------------------- packages
>>"%OUT%" echo --- Driver packages (J6 / dwcmshc / mshidkmdf) ---
pnputil.exe /enum-drivers >"%SystemRoot%\Temp\J6Drivers.txt" 2>&1
findstr /i /c:"J6Lte" /c:"dwcmshc" /c:"mshidkmdf" "%SystemRoot%\Temp\J6Drivers.txt" >>"%OUT%" 2>&1
>>"%OUT%" echo (full list in %SystemRoot%\Temp\J6Drivers.txt)
>>"%OUT%" echo.

rem ---------------------------------------------------------------- device nodes
>>"%OUT%" echo --- Device nodes ---
>>"%OUT%" echo [ROOT\J6ZT7548]
reg query "HKLM\SYSTEM\CurrentControlSet\Enum\ROOT\J6ZT7548" /s >>"%OUT%" 2>&1
>>"%OUT%" echo [ACPI devices matching ZTX]
reg query "HKLM\SYSTEM\CurrentControlSet\Enum\ACPI" /s /f "ZTX" >>"%OUT%" 2>&1
>>"%OUT%" echo [ACPI devices matching EXNS000A]
reg query "HKLM\SYSTEM\CurrentControlSet\Enum\ACPI" /s /f "EXNS000A" >>"%OUT%" 2>&1
>>"%OUT%" echo.

rem ---------------------------------------------------------------- storage
>>"%OUT%" echo --- Storage: diskpart ---
(
    echo list disk
    echo list volume
    echo select disk 0
    echo detail disk
    echo list partition
) > "%DP%"
diskpart.exe /s "%DP%" >>"%OUT%" 2>&1
>>"%OUT%" echo.
>>"%OUT%" echo --- Storage: mountvol ---
mountvol.exe >>"%OUT%" 2>&1
>>"%OUT%" echo.
>>"%OUT%" echo --- Storage: setupapi matches for the eMMC host ---
if exist "%SETUPAPI%" (
    findstr /i /c:"EXNS000A" /c:"dwcmshc" /c:"J6LteBt532Touch" /c:"mshidkmdf" "%SETUPAPI%" >"%SystemRoot%\Temp\J6SetupapiMatches.txt" 2>&1
    type "%SystemRoot%\Temp\J6SetupapiMatches.txt" >>"%OUT%"
) else (
    >>"%OUT%" echo %SETUPAPI% not found
)
>>"%OUT%" echo.

rem ---------------------------------------------------------------- distribute
echo.
echo ------------------------------------------------------------
type "%OUT%"
echo ------------------------------------------------------------
echo.

for %%D in (C D E F G H I J K L M N O P Q R S T U V W Y Z) do @if exist %%D:\ (
    copy /y "%OUT%" "%%D:\J6TouchDiag.txt" >nul 2>&1
    if exist "%SystemRoot%\Temp\J6TouchInstall.log" copy /y "%SystemRoot%\Temp\J6TouchInstall.log" "%%D:\J6TouchInstall.log" >nul 2>&1
    if exist "%SETUPAPI%" copy /y "%SETUPAPI%" "%%D:\J6Setupapi.log" >nul 2>&1
)
echo Report written to %OUT% and to every readable volume as J6TouchDiag.txt
echo.

if /i "%~1"=="--pause" pause
exit /b 0
