#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cfgmgr32.h>
#include <stdio.h>
#include <wchar.h>

typedef struct _DIAG_VALUE {
    const WCHAR* Name;
    const WCHAR* Label;
} DIAG_VALUE;

static const DIAG_VALUE DiagnosticValues[] = {
    { L"Stage",                 L"Stage" },
    { L"LastStatus",            L"Last status" },
    { L"PrepareHardwareStatus", L"Prepare HW" },
    { L"TransportMode",         L"Transport (1=ACPI 2=fixed)" },
    { L"MmioMapStatus",         L"MMIO map" },
    { L"Ldo34Status",           L"LDO34" },
    { L"PowerSequenceStatus",   L"ZT7548 power sequence" },
    { L"ControllerStartStatus", L"Controller start" },
    { L"ControllerInitStatus",  L"Controller init" },
    { L"ChipCode",              L"Chip code (expect E548)" },
    { L"InitialGpa0Data",       L"GPA0 data" },
    { L"InitialTouchIicCon",    L"I2C CON" },
    { L"InitialTouchIicStat",   L"I2C STAT" },
    { L"FirstInputStatus",      L"First input" },
};

static
BOOL
RegistryKeyExists(
    _In_z_ const WCHAR* Path
    )
{
    HKEY key;
    LSTATUS result;

    result = RegOpenKeyExW(HKEY_LOCAL_MACHINE, Path, 0, KEY_READ, &key);
    if (result == ERROR_SUCCESS) {
        RegCloseKey(key);
        return TRUE;
    }
    return FALSE;
}

static
BOOL
StartsWithInsensitive(
    _In_z_ const WCHAR* Text,
    _In_z_ const WCHAR* Prefix
    )
{
    size_t prefixLength = wcslen(Prefix);

    return (_wcsnicmp(Text, Prefix, prefixLength) == 0);
}

static
VOID
PrintStorageStatus(void)
{
    CONFIGRET configResult;
    ULONG idListLength = 0;
    WCHAR* idList = NULL;
    WCHAR* deviceId;
    BOOL hostFound = FALSE;
    ULONG hostStatus = 0;
    ULONG hostProblem = 0;
    ULONG diskCount = 0;
    ULONG sdDiskCount = 0;
    ULONG scsiDiskCount = 0;
    ULONG rootDiskCount = 0;
    ULONG badDiskCount = 0;
    DWORD driveMask;
    DWORD driveIndex;

    configResult = CM_Get_Device_ID_List_SizeW(
        &idListLength,
        NULL,
        CM_GETIDLIST_FILTER_NONE);
    if (configResult == CR_SUCCESS && idListLength != 0) {
        idList = (WCHAR*)HeapAlloc(
            GetProcessHeap(),
            HEAP_ZERO_MEMORY,
            idListLength * sizeof(WCHAR));
    }

    if (idList != NULL) {
        configResult = CM_Get_Device_ID_ListW(
            NULL,
            idList,
            idListLength,
            CM_GETIDLIST_FILTER_NONE);
    }

    if (idList == NULL || configResult != CR_SUCCESS) {
        wprintf(L"eMMC host: device enumeration failed (CR=0x%08lX)\n", configResult);
    } else {
        for (deviceId = idList; *deviceId != L'\0'; deviceId += wcslen(deviceId) + 1) {
            DEVINST deviceInstance;

            configResult = CM_Locate_DevNodeW(
                &deviceInstance,
                deviceId,
                CM_LOCATE_DEVNODE_NORMAL);
            if (configResult != CR_SUCCESS) {
                continue;
            }

            if (!hostFound && StartsWithInsensitive(deviceId, L"ACPI\\EXNS000A\\")) {
                hostFound = TRUE;
                configResult = CM_Get_DevNode_Status(
                    &hostStatus,
                    &hostProblem,
                    deviceInstance,
                    0);
                if (configResult != CR_SUCCESS) {
                    hostStatus = 0;
                    hostProblem = 0xFFFFFFFF;
                }
            }

            {
                WCHAR className[64];
                ULONG classNameSize = sizeof(className);
                ULONG valueType = 0;

                configResult = CM_Get_DevNode_Registry_PropertyW(
                    deviceInstance,
                    CM_DRP_CLASS,
                    &valueType,
                    className,
                    &classNameSize,
                    0);
                if (configResult != CR_SUCCESS ||
                    _wcsicmp(className, L"DiskDrive") != 0) {
                    continue;
                }
            }

            ++diskCount;
            if (StartsWithInsensitive(deviceId, L"SD\\")) {
                ++sdDiskCount;
            } else if (StartsWithInsensitive(deviceId, L"SCSI\\")) {
                ++scsiDiskCount;
            } else if (StartsWithInsensitive(deviceId, L"ROOT\\")) {
                ++rootDiskCount;
            }

            {
                ULONG diskStatus = 0;
                ULONG diskProblem = 0;

                if (CM_Get_DevNode_Status(
                        &diskStatus,
                        &diskProblem,
                        deviceInstance,
                        0) != CR_SUCCESS ||
                    diskProblem != 0) {
                    ++badDiskCount;
                }
            }
        }

        if (hostFound) {
            wprintf(
                L"eMMC host: status=0x%08lX problem=%lu (0x%08lX)\n",
                hostStatus,
                hostProblem,
                hostProblem);
        } else {
            wprintf(L"eMMC host: ACPI\\EXNS000A not present\n");
        }
    }

    if (idList != NULL) {
        HeapFree(GetProcessHeap(), 0, idList);
    }

    wprintf(
        L"Disk devices: total=%lu SD=%lu SCSI=%lu ROOT=%lu bad=%lu\n",
        diskCount,
        sdDiskCount,
        scsiDiskCount,
        rootDiskCount,
        badDiskCount);

    driveMask = GetLogicalDrives();
    wprintf(L"Mounted drives:");
    if (driveMask == 0) {
        wprintf(L" none (error %lu)", GetLastError());
    } else {
        for (driveIndex = 0; driveIndex < 26; ++driveIndex) {
            WCHAR rootPath[] = L"A:\\";
            WCHAR fileSystem[32] = L"?";

            if ((driveMask & (1UL << driveIndex)) == 0) {
                continue;
            }

            rootPath[0] = (WCHAR)(L'A' + driveIndex);
            (VOID)GetVolumeInformationW(
                rootPath,
                NULL,
                0,
                NULL,
                NULL,
                NULL,
                fileSystem,
                ARRAYSIZE(fileSystem));
            wprintf(L" %c:(%ls)", rootPath[0], fileSystem);
        }
    }
    wprintf(L"\n");
}

int
wmain(void)
{
    DEVINST deviceInstance;
    CONFIGRET configResult;
    ULONG deviceStatus = 0;
    ULONG problemCode = 0;
    HKEY parameters;
    LSTATUS result;
    DWORD index;

    wprintf(L"ROOT device: ");
    configResult = CM_Locate_DevNodeW(
        &deviceInstance,
        L"ROOT\\J6ZT7548\\0000",
        CM_LOCATE_DEVNODE_NORMAL);
    if (configResult == CR_SUCCESS) {
        configResult = CM_Get_DevNode_Status(
            &deviceStatus,
            &problemCode,
            deviceInstance,
            0);
    }
    if (configResult == CR_SUCCESS) {
        wprintf(
            L"status=0x%08lX problem=%lu (0x%08lX)\n",
            deviceStatus,
            problemCode,
            problemCode);
    } else {
        wprintf(L"not available (CR=0x%08lX)\n", configResult);
    }

    wprintf(
        L"Services: touch=%ls mshidkmdf=%ls storage=%ls\n",
        RegistryKeyExists(L"SYSTEM\\CurrentControlSet\\Services\\J6LteBt532Touch") ? L"yes" : L"no",
        RegistryKeyExists(L"SYSTEM\\CurrentControlSet\\Services\\mshidkmdf") ? L"yes" : L"no",
        RegistryKeyExists(L"SYSTEM\\CurrentControlSet\\Services\\dwcmshc") ? L"yes" : L"no");

    PrintStorageStatus();

    result = RegOpenKeyExW(
        HKEY_LOCAL_MACHINE,
        L"SYSTEM\\CurrentControlSet\\Services\\J6LteBt532Touch\\Parameters",
        0,
        KEY_READ,
        &parameters);
    if (result != ERROR_SUCCESS) {
        wprintf(L"Driver diagnostics unavailable (registry error %ld)\n", result);
        return 1;
    }

    for (index = 0; index < ARRAYSIZE(DiagnosticValues); ++index) {
        DWORD value = 0;
        DWORD valueType = 0;
        DWORD valueSize = sizeof(value);

        result = RegQueryValueExW(
            parameters,
            DiagnosticValues[index].Name,
            NULL,
            &valueType,
            (BYTE*)&value,
            &valueSize);
        if (result == ERROR_SUCCESS && valueType == REG_DWORD) {
            wprintf(
                L"%-29ls 0x%08lX\n",
                DiagnosticValues[index].Label,
                value);
        } else {
            wprintf(L"%-29ls --\n", DiagnosticValues[index].Label);
        }
    }

    RegCloseKey(parameters);
    return 0;
}
