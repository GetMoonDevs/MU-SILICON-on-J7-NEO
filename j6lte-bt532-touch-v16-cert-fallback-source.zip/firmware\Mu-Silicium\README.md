# Mu-Silicium j6lte platform overlay (failed experiment)

> **Do not flash this overlay's output.** Windows Boot Manager failed during
> `BlInitializeLibrary` with `0xC0000225`. The added MMIO memory descriptors are
> a likely firmware memory-map fragmentation regression. The current WinPE
> approach keeps the known-booting firmware unchanged and root-enumerates the
> touch device instead.

The upstream S5E7870/gtaxllte ACPI currently describes CPUs and eMMC only. It
does not expose an I2C controller, GPIO controller, or touchscreen to Windows.
Changing its SMBIOS name and framebuffer dimensions is therefore insufficient
for j6lte touchscreen support.

This overlay adds a separate `j6ltePkg` with:

- 720 x 1480 framebuffer dimensions and j6lte SMBIOS strings;
- page-backed MMIO regions needed by the bootstrap touch transport;
- an SSDT exposing `ACPI\ZTX7548` and its seven fixed MMIO resources;
- the actual j6lte power, volume-up, and volume-down button mapping.

Apply it to an initialized Mu-Silicium checkout:

```powershell
powershell -ExecutionPolicy Bypass -File .\apply-overlay.ps1 `
  -MuRoot C:\path\to\Mu-Silicium
```

Then build a non-Secure-Boot development image:

```console
python build_uefi.py -d j6lte -r RELEASE -c
```

The compiled `SSDT.aml` is intentionally included so EDK2 packages the same
table that was validated by the WDK ASL compiler. Re-run
`scripts\validate-acpi.ps1` and copy its output over `SSDT.aml` after changing
the ASL source.

This is a board-specific bring-up path. A future production port should replace
the direct MMIO resources with native Windows SpbCx and GpioClx controller
drivers.
