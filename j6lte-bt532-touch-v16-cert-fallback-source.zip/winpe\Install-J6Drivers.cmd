@echo off
rem ===========================================================================
rem  J6Touch - Samsung Galaxy J6 (SM-J600G)
rem  eMMC (dwcmshc) + Zinitix ZT7548 touch driver installer - Windows PE build
rem
rem  Stages both driver packages, trusts the WDK test certificate, creates the
rem  ROOT\J6ZT7548 device node and rescans PnP.  Safe to run repeatedly.
rem
rem  Exit codes: 0 = installed, 2 = at least one step failed (see log),
rem              1 = reboot required (only reported by the helpers).
rem ===========================================================================
setlocal EnableExtensions EnableDelayedExpansion

set "ROOT=X:\J6Touch"
if not exist "%ROOT%\J6LteBt532Touch\J6LteBt532Touch.inf" for %%I in ("%~dp0.") do set "ROOT=%%~fI"
set "TOOLS=%ROOT%\tools"
set "TOUCH=%ROOT%\J6LteBt532Touch"
set "STORAGE=%ROOT%\dwcmshc"
set "LOG=%SystemRoot%\Temp\J6TouchInstall.log"
set "BCD=%SystemRoot%\Temp\J6Bcd.txt"
set "NOW=%SystemRoot%\Temp\J6DiagNow.txt"
set "FAILED="

echo ============================================================
echo   J6 touch + eMMC driver install  (Windows PE)
echo ============================================================
echo.
echo Payload : %ROOT%
echo Log     : %LOG%
echo.

>>"%LOG%" echo.
>>"%LOG%" echo ============================================================
>>"%LOG%" echo  Install run %DATE% %TIME%
>>"%LOG%" echo  Payload: %ROOT%
>>"%LOG%" echo ============================================================

rem --- 0. Record the boot policy (test signing must be on) ------------------
echo [0/4] Recording boot configuration...
bcdedit.exe /enum all >"%BCD%" 2>&1
if exist "%BCD%" (
    findstr /i /c:"testsigning" /c:"nointegritychecks" "%BCD%" >>"%LOG%" 2>&1
    echo        recorded to %BCD%
) else (
    echo        bcdedit produced no output
)

rem --- 1. Trust the test signing certificate --------------------------------
echo [1/4] Trusting the WDK test certificate...
if exist "%TOOLS%\J6TrustCert.exe" (
    "%TOOLS%\J6TrustCert.exe" "%TOUCH%\J6LteBt532Touch.cer" >>"%LOG%" 2>&1
    set "CERTRC=!ERRORLEVEL!"
    if !CERTRC! GEQ 2 (
        echo        FAILED - J6TrustCert exit !CERTRC!
        set "FAILED=1"
    ) else (
        echo        ok - J6TrustCert exit !CERTRC!
    )
) else (
    echo        FAILED - %TOOLS%\J6TrustCert.exe is missing
    set "FAILED=1"
)

rem --- 2. Provide MsHidKmdf.inf (Include/Needs target of the touch INF) -----
echo [2/4] Staging MsHidKmdf.inf...
if exist "%SystemRoot%\INF\MsHidKmdf.inf" (
    echo        already present in %SystemRoot%\INF
) else if exist "%ROOT%\MsHidKmdf.inf" (
    copy /y "%ROOT%\MsHidKmdf.inf" "%SystemRoot%\INF\MsHidKmdf.inf" >>"%LOG%" 2>&1
    if errorlevel 1 (
        echo        FAILED - cannot write %SystemRoot%\INF\MsHidKmdf.inf
        set "FAILED=1"
    ) else (
        echo        copied to %SystemRoot%\INF
    )
) else (
    echo        FAILED - %ROOT%\MsHidKmdf.inf is missing
    set "FAILED=1"
)

rem --- 3. eMMC: EXNS000A SD host controller (dwcmshc) ----------------------
echo [3/4] Installing the Exynos 7870 eMMC driver (dwcmshc)...
if not exist "%STORAGE%\dwcmshc.inf" (
    echo        FAILED - %STORAGE%\dwcmshc.inf is missing
    set "FAILED=1"
    goto :touch
)
drvload.exe "%STORAGE%\dwcmshc.inf" >>"%LOG%" 2>&1
set "DWC=!ERRORLEVEL!"
pnputil.exe /add-driver "%STORAGE%\dwcmshc.inf" /install >>"%LOG%" 2>&1
set "DWC2=!ERRORLEVEL!"
if !DWC2! NEQ 0 (
    pnputil.exe /add-driver "%STORAGE%\dwcmshc.inf" >>"%LOG%" 2>&1
    set "DWC2=!ERRORLEVEL!"
)
echo        drvload exit=!DWC!  pnputil exit=!DWC2!
if !DWC! NEQ 0 if !DWC2! NEQ 0 set "FAILED=1"

rem --- 4. Touch: create ROOT\J6ZT7548 and install the driver ---------------
:touch
echo [4/4] Installing the ZT7548 touch driver...
if not exist "%TOOLS%\J6CreateDevice.exe" (
    echo        FAILED - %TOOLS%\J6CreateDevice.exe is missing
    set "FAILED=1"
    goto :rescan
)
"%TOOLS%\J6CreateDevice.exe" "%TOUCH%\J6LteBt532Touch.inf" >>"%LOG%" 2>&1
set "DEVRC=!ERRORLEVEL!"
echo        J6CreateDevice exit=!DEVRC!
if !DEVRC! GEQ 2 set "FAILED=1"

:rescan
echo        Rescanning PnP devices...
pnputil.exe /scan-devices >>"%LOG%" 2>&1

rem --- Summary --------------------------------------------------------------
echo.
if exist "%TOOLS%\J6Diag.exe" (
    echo ------------------------------------------------------------
    "%TOOLS%\J6Diag.exe" >"%NOW%" 2>&1
    type "%NOW%"
    type "%NOW%" >>"%LOG%"
    echo ------------------------------------------------------------
)

if defined FAILED (
    echo Result   : FAILED - see %LOG%
) else (
    echo Result   : drivers staged.  Run J6TouchDiag.cmd for a full report.
)
echo.

rem --- Copy the log next to every readable volume ---------------------------
for %%D in (C D E F G H I J K L M N O P Q R S T U V W Y Z) do @if exist %%D:\ copy /y "%LOG%" "%%D:\J6TouchInstall.log" >nul 2>&1

if defined FAILED exit /b 2
exit /b 0
